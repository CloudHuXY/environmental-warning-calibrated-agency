# Study 3 design decision after source audit

## Decision

Study 3 is divided into two claim-specific analyses.

**Study 3A — global physical-event coverage.** NOAA IBTrACS and the NASA Global Landslide Catalog establish the geographic and hazard-space coverage of the case framework. This component supports claims about event diversity and physical-risk baselines. It does not use physical occurrence as a proxy for public understanding or action.

**Study 3B — official archive linkage.** FEMA IPAWS archived CAP messages are linked to NOAA Storm Events records for U.S. tropical-cyclone, flood, and debris-flow events from 2012–2025. Prespecified message features include lead time, severity, certainty, mechanism explanation, map/polygon presence, and action specificity. Outcomes are deaths, injuries, property damage, and disruption or evacuation language documented by NOAA. The analysis tests incremental prediction beyond physical intensity and exposure controls. Because alert issuance is observational and confounded, coefficients are not described as causal effects.

The causal effect of message format on risk perception and intended protective action remains identified by the randomized survey experiments in Studies 1 and 2. Study 3B is an external predictive and ecological validity check.

## Why the design changed

There is no single complete global historical CAP-plus-behavior archive. DesInventar definitions and coverage vary by country, and a recorded zero in an evacuation field can mean either no evacuation or no reporting. Treating those records as globally comparable behavioral outcomes would create outcome misclassification.

FEMA IPAWS supplies authoritative CAP messages from 2012 onward. NOAA Storm Events supplies official event details, narratives, deaths, injuries, and damages. Their shared U.S. geography and dates permit auditable linkage, while IBTrACS provides an independent physical storm-intensity source.

## Claim gates

1. Study 3A results may be reported only when both downloaded source files pass hash, schema, date, and duplicate checks.
2. Study 3B results may be reported only when the official FEMA and NOAA files are present, alert-to-event matching diagnostics are disclosed, and at least 500 linked events remain.
3. Unreported outcomes remain missing. Narrative mentions of an evacuation order measure government action, not household compliance.
4. Deaths, injuries, damage, and post-event narrative content cannot be used as predictors of earlier public action.
5. Study 3B supports incremental prediction and transport evidence; it does not replace the randomized evidence in Studies 1 and 2.
