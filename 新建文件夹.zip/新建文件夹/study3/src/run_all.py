"""Run Study 3 audit, harmonization, and estimation in dependency order."""
from pathlib import Path
import subprocess, sys

HERE=Path(__file__).resolve().parent
for script in ["audit_and_prepare.py","analyze_global_coverage.py","build_model_table.py","fit_external_models.py"]:
    print(f"\n[{script}]")
    completed=subprocess.run([sys.executable,str(HERE/script)],check=False)
    if completed.returncode:
        raise SystemExit(completed.returncode)
