"""Download official U.S. warning and impact archives for Study 3B.

FEMA IPAWS is queried by hazard code and calendar year to keep requests bounded.
NOAA Storm Events detail files are selected from the official bulk directory.
Downloads are resumable at the file level and never overwrite existing raw files.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/"data_raw"; OUT=ROOT/"outputs"
FEMA="https://www.fema.gov/api/open/v1/IpawsArchivedAlerts"
NOAA="https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/"
CODES=["HUW","HLS","TRW","FFW","FLW"]

def get(url,timeout=120):
    req=urllib.request.Request(url,headers={"User-Agent":"Environmental-Health-Message-Lab/1.0 research"})
    with urllib.request.urlopen(req,timeout=timeout) as r: return r.read()

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def download_ipaws():
    path=RAW/"fema_ipaws_hazard_alerts.jsonl"
    if path.exists(): return {"status":"existing","path":str(path),"sha256":sha(path)}
    tmp=path.with_suffix(".jsonl.part"); seen=set(); count=0
    with tmp.open("w",encoding="utf-8") as out:
        for year in range(2012,2026):
            for code in CODES:
                skip=0
                while True:
                    filt=(f"sent ge '{year}-01-01T00:00:00.000Z' and sent lt '{year+1}-01-01T00:00:00.000Z' "
                          f"and contains(infos/eventCode/value,'{code}')")
                    q={"$filter":filt,"$top":"1000","$skip":str(skip),"$orderby":"sent asc"}
                    url=FEMA+"?"+urllib.parse.urlencode(q)
                    payload=json.loads(get(url).decode("utf-8")); rows=payload.get("IpawsArchivedAlerts",[])
                    if not rows: break
                    for row in rows:
                        key=(row.get("identifier"),row.get("sent"),row.get("sender"))
                        if key in seen: continue
                        seen.add(key); row["_query_event_code"]=code
                        out.write(json.dumps(row,ensure_ascii=False)+"\n"); count+=1
                    if len(rows)<1000: break
                    skip+=len(rows); time.sleep(.1)
    tmp.replace(path); return {"status":"downloaded","path":str(path),"records":count,"sha256":sha(path)}

def download_noaa():
    folder=RAW/"noaa_storm_events"; folder.mkdir(exist_ok=True)
    html=get(NOAA).decode("utf-8",errors="replace"); results=[]
    for year in range(2012,2026):
        names=re.findall(r'href="(StormEvents_details-ftp_v1\.0_d'+str(year)+r'_c\d+\.csv\.gz)"',html)
        if not names: results.append({"year":year,"status":"not_listed"}); continue
        name=sorted(names)[-1]; path=folder/name
        if not path.exists():
            temp=path.with_suffix(path.suffix+".part"); temp.write_bytes(get(NOAA+name)); temp.replace(path)
        # gzip CRC check before receipt.
        with gzip.open(path,"rb") as f:
            while f.read(1024*1024): pass
        results.append({"year":year,"status":"ready","file":name,"sha256":sha(path)})
    return results

def main():
    RAW.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    receipt={"created_at_utc":datetime.now(timezone.utc).isoformat(),"sources":{}}
    for name,fn in [("fema_ipaws",download_ipaws),("noaa_storm_events",download_noaa)]:
        try: receipt["sources"][name]=fn()
        except Exception as exc: receipt["sources"][name]={"status":"failed","error":repr(exc)}
    (OUT/"us_archive_download_receipt.json").write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(receipt,indent=2,ensure_ascii=False)); return 0
if __name__=="__main__": raise SystemExit(main())
