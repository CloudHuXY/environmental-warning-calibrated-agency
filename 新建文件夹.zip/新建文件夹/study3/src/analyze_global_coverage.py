"""Create source-backed Study 3A coverage tables and a publication-ready figure."""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
PROC,OUT,FIG=ROOT/"data_processed",ROOT/"outputs",ROOT/"figures"

def font(size,bold=False):
    names=[Path(r"C:\Windows\Fonts\arialbd.ttf") if bold else Path(r"C:\Windows\Fonts\arial.ttf")]
    for p in names:
        if p.exists(): return ImageFont.truetype(str(p),size)
    return ImageFont.load_default()

def map_xy(lon,lat,left,top,width,height):
    return left+(float(lon)+180)/360*width, top+(90-float(lat))/180*height

def main():
    OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)
    storms=pd.read_csv(PROC/"ibtracs_storm_events_2007_2025.csv")
    tracks=pd.read_csv(PROC/"ibtracs_track_points_2007_2025.csv")
    lands=pd.read_csv(PROC/"nasa_landslide_events_2007_2025.csv")
    lands["event_date"]=pd.to_datetime(lands.event_date,errors="coerce",utc=True)
    lands["year"]=lands.event_date.dt.year

    annual=pd.DataFrame({"year":range(2007,2026)})
    annual=annual.merge(storms.groupby("season").size().rename("storm_events"),left_on="year",right_index=True,how="left")
    annual=annual.merge(lands.groupby("year").size().rename("landslide_reports"),left_on="year",right_index=True,how="left").fillna(0)
    annual.to_csv(OUT/"Table_S3A_AnnualCoverage.csv",index=False)
    storms.groupby("basin",dropna=False).agg(storm_events=("storm_id","nunique"),median_max_wind_kt=("max_wind_kt","median"),landfall_share=("landfall_flag","mean")).reset_index().to_csv(OUT/"Table_S3A_StormsByBasin.csv",index=False)
    lands.groupby("country",dropna=False).agg(landslide_reports=("event_id","count"),fatalities_known=("fatalities","count"),reported_fatalities=("fatalities","sum")).reset_index().sort_values("landslide_reports",ascending=False).to_csv(OUT/"Table_S3A_LandslidesByCountry.csv",index=False)

    coverage=pd.DataFrame([
        {"source":"NOAA IBTrACS v04r01","analysis_window":"2007–2025","records":len(storms),"unit":"unique storm","geographic_coverage":"global basins","key_limit":"physical hazard data; no public-response outcome"},
        {"source":"NASA Global Landslide Catalog","analysis_window":"2007–2017 in downloaded export","records":len(lands),"unit":"reported landslide","geographic_coverage":f"{lands.country.nunique(dropna=True)} named countries","key_limit":"reporting/media selection bias; coverage ends in 2017"},
    ])
    coverage.to_csv(OUT/"Table_S3A_SourceCoverage.csv",index=False)

    W,H=2400,1800; im=Image.new("RGB",(W,H),"white"); d=ImageDraw.Draw(im)
    navy="#17324D"; blue="#2878B5"; orange="#D86727"; grid="#D9E1E8"; grey="#5C6770"
    d.text((100,55),"Global coverage of tropical-cyclone tracks and reported landslides",font=font(54,True),fill=navy)
    d.text((100,125),"Observed public datasets used for Study 3A; point density reflects source coverage as well as hazard occurrence",font=font(29),fill=grey)
    L,T,MW,MH=120,215,2160,820
    d.rectangle((L,T,L+MW,T+MH),outline=navy,width=3)
    for lon in range(-180,181,30):
        x,_=map_xy(lon,0,L,T,MW,MH); d.line((x,T,x,T+MH),fill=grid,width=2)
        d.text((x-25,T+MH+12),str(lon),font=font(18),fill=grey)
    for lat in range(-60,91,30):
        _,y=map_xy(0,lat,L,T,MW,MH); d.line((L,y,L+MW,y),fill=grid,width=2)
        d.text((L-58,y-10),str(lat),font=font(18),fill=grey)
    overlay=Image.new("RGBA",(W,H),(255,255,255,0)); od=ImageDraw.Draw(overlay)
    t=tracks.iloc[::4]
    for lon,lat in zip(t.lon,t.lat):
        if pd.notna(lon) and pd.notna(lat):
            x,y=map_xy(lon,lat,L,T,MW,MH); od.ellipse((x-2,y-2,x+2,y+2),fill=(40,120,181,32))
    for lon,lat in zip(lands.longitude,lands.latitude):
        if pd.notna(lon) and pd.notna(lat):
            x,y=map_xy(lon,lat,L,T,MW,MH); od.ellipse((x-3,y-3,x+3,y+3),fill=(216,103,39,70))
    im=Image.alpha_composite(im.convert("RGBA"),overlay).convert("RGB"); d=ImageDraw.Draw(im)
    d.ellipse((L+30,T+25,L+46,T+41),fill=blue); d.text((L+58,T+19),"IBTrACS track points",font=font(24),fill=navy)
    d.ellipse((L+340,T+25,L+356,T+41),fill=orange); d.text((L+368,T+19),"NASA landslide reports",font=font(24),fill=navy)

    # Annual coverage panels use separate axes because counts are not commensurate.
    chart_top=1160; chart_h=390; left1=150; width1=950; left2=1300; width2=950
    def bars(left,width,values,title,color,maxv):
        d.text((left,chart_top-70),title,font=font(32,True),fill=navy)
        d.line((left,chart_top,left,chart_top+chart_h),fill=navy,width=3); d.line((left,chart_top+chart_h,left+width,chart_top+chart_h),fill=navy,width=3)
        bw=width/len(values)
        for i,v in enumerate(values):
            bh=0 if maxv==0 else float(v)/maxv*(chart_h-20)
            x=left+i*bw+5; d.rectangle((x,chart_top+chart_h-bh,x+bw-8,chart_top+chart_h),fill=color)
            if i%3==0: d.text((x-4,chart_top+chart_h+12),str(2007+i),font=font(17),fill=grey)
        d.text((left-5,chart_top-28),str(int(maxv)),font=font(18),fill=grey); d.text((left-5,chart_top+chart_h-10),"0",font=font(18),fill=grey)
    bars(left1,width1,annual.storm_events,"A. Tropical-cyclone events by season",blue,annual.storm_events.max())
    bars(left2,width2,annual.landslide_reports,"B. Landslide reports by event year",orange,annual.landslide_reports.max())
    d.text((100,1695),"Sources: NOAA IBTrACS v04r01 and NASA Global Landslide Catalog. NASA export coverage ends in 2017; later zeros are not evidence of no events.",font=font(24),fill=grey)
    path=FIG/"Figure_Study3A_GlobalCoverage.png"; im.save(path,dpi=(300,300),optimize=True)

    summary={"storm_events_2007_2025":int(len(storms)),"storm_track_points":int(len(tracks)),"storm_basins_named":int(storms.basin.nunique(dropna=True)),
             "landslide_reports_2007_2017":int(len(lands)),"landslide_named_countries":int(lands.country.nunique(dropna=True)),
             "landslide_date_max":lands.event_date.max().isoformat(),"figure":str(path),"claim_scope":"descriptive global physical-event coverage only"}
    (OUT/"study3a_coverage_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))

if __name__=="__main__": main()
