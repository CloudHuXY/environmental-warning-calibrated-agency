"""Audit Study 3 inputs and build event-level feature tables.

Outputs are created only from source rows. Missing values remain missing unless a
documented deterministic derivation is possible. The audit status blocks model
claims when required datasets or fields are absent.
"""
from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data_raw"
PROCESSED = ROOT / "data_processed"
OUT = ROOT / "outputs"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def col(df: pd.DataFrame, *names: str) -> str | None:
    lookup = {str(c).strip().lower(): c for c in df.columns}
    for name in names:
        if name.lower() in lookup:
            return lookup[name.lower()]
    return None


def numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.replace({" ": np.nan, "": np.nan}), errors="coerce")


def audit_frame(df: pd.DataFrame, key_candidates: list[list[str]], date_candidates: list[str]) -> dict:
    missing_view = df.replace(r"^\s*$", np.nan, regex=True)
    result = {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "exact_duplicate_rows": int(df.duplicated().sum()),
        "missing_rate_top": missing_view.isna().mean().sort_values(ascending=False).head(20).round(4).to_dict(),
    }
    for keys in key_candidates:
        actual = [col(df, k) for k in keys]
        if all(actual):
            result["candidate_key"] = keys
            result["duplicate_candidate_keys"] = int(df.duplicated(actual).sum())
            break
    for name in date_candidates:
        c = col(df, name)
        if c:
            dates = pd.to_datetime(df[c], errors="coerce", utc=True, format="mixed")
            result["date_column"] = str(c)
            result["date_parse_failure_rate"] = round(float(dates.isna().mean()), 4)
            result["date_min"] = None if dates.dropna().empty else dates.min().isoformat()
            result["date_max"] = None if dates.dropna().empty else dates.max().isoformat()
            break
    return result


def prepare_ibtracs(path: Path) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    df = pd.read_csv(path, low_memory=False, skiprows=[1])
    audit = audit_frame(df, [["SID", "ISO_TIME"]], ["ISO_TIME"])
    sid, season, basin, name = [col(df, x) for x in ["SID", "SEASON", "BASIN", "NAME"]]
    time, lat, lon = [col(df, x) for x in ["ISO_TIME", "LAT", "LON"]]
    wind = col(df, "WMO_WIND", "USA_WIND")
    pressure = col(df, "WMO_PRES", "USA_PRES")
    dist_land = col(df, "DIST2LAND")
    landfall = col(df, "LANDFALL")
    track_type = col(df, "TRACK_TYPE")
    required = [sid, season, basin, time, lat, lon]
    if not all(required):
        raise ValueError("IBTrACS core columns are missing")
    work = pd.DataFrame({
        "storm_id": df[sid].astype(str), "season": numeric(df[season]), "basin": df[basin].astype(str),
        "name": df[name].astype(str) if name else "", "time": pd.to_datetime(df[time], errors="coerce", utc=True),
        "lat": numeric(df[lat]), "lon": numeric(df[lon]),
        "wind_kt": numeric(df[wind]) if wind else np.nan,
        "pressure_mb": numeric(df[pressure]) if pressure else np.nan,
        "distance_to_land_km": numeric(df[dist_land]) if dist_land else np.nan,
        "landfall_distance_km": numeric(df[landfall]) if landfall else np.nan,
        "track_type": df[track_type].astype(str) if track_type else "",
    })
    work = work[(work["season"] >= 2007) & (work["season"] <= 2025)]
    if track_type:
        work = work[~work["track_type"].str.lower().str.contains("spur", na=False)]
    work = work.dropna(subset=["storm_id", "time", "lat", "lon"]).sort_values(["storm_id", "time"])
    work["wind_change_24h"] = work.groupby("storm_id")["wind_kt"].diff(4)
    def summarize(g: pd.DataFrame) -> pd.Series:
        duration = (g["time"].max() - g["time"].min()).total_seconds() / 3600 if len(g) else np.nan
        return pd.Series({
            "season": g["season"].dropna().iloc[0] if g["season"].notna().any() else np.nan,
            "basin": g["basin"].dropna().iloc[0] if g["basin"].notna().any() else "",
            "name": g["name"].dropna().iloc[0] if g["name"].notna().any() else "",
            "start_time": g["time"].min(), "end_time": g["time"].max(), "duration_hours": duration,
            "max_wind_kt": g["wind_kt"].max(), "min_pressure_mb": g["pressure_mb"].min(),
            "min_distance_to_land_km": g["distance_to_land_km"].min(),
            "landfall_flag": int((g["landfall_distance_km"] == 0).any()),
            "max_24h_intensification_kt": g["wind_change_24h"].max(),
            "track_points": len(g),
        })
    try:
        events = work.groupby("storm_id", sort=False).apply(summarize, include_groups=False).reset_index()
    except TypeError:  # pandas < 2.2
        events = work.groupby("storm_id", sort=False).apply(summarize).reset_index()
    audit["filtered_2007_2025_track_rows"] = int(len(work))
    audit["storm_events"] = int(len(events))
    tracks = work[["storm_id","season","basin","name","time","lat","lon","wind_kt",
                   "pressure_mb","distance_to_land_km","landfall_distance_km"]].copy()
    return events, tracks, audit


def prepare_landslides(path: Path) -> tuple[pd.DataFrame, dict]:
    df = pd.read_csv(path, low_memory=False)
    audit = audit_frame(df, [["event_id"], ["id"]], ["event_date", "date"])
    mapping = {
        "event_id": ("event_id", "id"), "event_date": ("event_date", "date"),
        "latitude": ("latitude", "lat"), "longitude": ("longitude", "lon", "lng"),
        "country": ("country_name", "country"), "admin1": ("admin_division_name", "admin1", "state"),
        "landslide_type": ("landslide_category", "landslide_type", "type"),
        "trigger": ("landslide_trigger", "trigger"), "size": ("landslide_size", "size"),
        "fatalities": ("fatality_count", "fatalities", "deaths"),
        "injuries": ("injury_count", "injuries"),
    }
    out = pd.DataFrame(index=df.index)
    for target, candidates in mapping.items():
        c = col(df, *candidates)
        out[target] = df[c] if c else np.nan
    out["event_date"] = pd.to_datetime(out["event_date"], errors="coerce", utc=True, format="mixed")
    for c in ["latitude", "longitude", "fatalities", "injuries"]:
        out[c] = numeric(out[c])
    out = out[(out["event_date"].dt.year >= 2007) & (out["event_date"].dt.year <= 2025)]
    out["reported_fatal_event"] = np.where(out["fatalities"].notna(), (out["fatalities"] > 0).astype(int), np.nan)
    audit["filtered_2007_2025_events"] = int(len(out))
    audit["fatality_known_rate"] = round(float(out["fatalities"].notna().mean()), 4) if len(out) else 0
    return out, audit


def audit_optional_csv(path: Path, required: list[str]) -> tuple[pd.DataFrame | None, dict]:
    if not path.exists():
        return None, {"status": "missing", "required_columns": required}
    df = pd.read_csv(path, low_memory=False)
    missing = [x for x in required if col(df, x) is None]
    return df, {"status": "ready" if not missing else "invalid", "missing_columns": missing,
                **audit_frame(df, [["event_id"]], ["event_date", "sent_time"])}


def main() -> int:
    PROCESSED.mkdir(parents=True, exist_ok=True); OUT.mkdir(parents=True, exist_ok=True)
    status = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "sources": {}, "model_ready": False}
    ib = RAW / "ibtracs.since1980.list.v04r01.csv"
    glc = RAW / "Global_Landslide_Catalog_Export_rows.csv"
    if ib.exists():
        try:
            events, tracks, audit = prepare_ibtracs(ib)
            events.to_csv(PROCESSED / "ibtracs_storm_events_2007_2025.csv", index=False)
            tracks.to_csv(PROCESSED / "ibtracs_track_points_2007_2025.csv", index=False)
            status["sources"]["ibtracs"] = {"status": "ready", "sha256": sha256(ib), **audit}
        except Exception as exc: status["sources"]["ibtracs"] = {"status": "invalid", "error": repr(exc)}
    else: status["sources"]["ibtracs"] = {"status": "missing"}
    if glc.exists():
        try:
            events, audit = prepare_landslides(glc); events.to_csv(PROCESSED / "nasa_landslide_events_2007_2025.csv", index=False)
            status["sources"]["nasa_glc"] = {"status": "ready", "sha256": sha256(glc), **audit}
        except Exception as exc: status["sources"]["nasa_glc"] = {"status": "invalid", "error": repr(exc)}
    else: status["sources"]["nasa_glc"] = {"status": "missing"}
    _, des = audit_optional_csv(RAW / "desinventar_events.csv", ["event_id","event_date","country","hazard_type","deaths","affected","evacuated"])
    _, cap = audit_optional_csv(RAW / "cap_alerts.csv", ["alert_id","sent_time","country","event","severity","urgency","certainty","area_description","instruction"])
    status["sources"]["desinventar"] = des; status["sources"]["cap"] = cap
    status["coverage_ready"] = all(status["sources"].get(x,{}).get("status") == "ready" for x in ["ibtracs","nasa_glc"])
    status["model_ready"] = all(status["sources"].get(x,{}).get("status") == "ready" for x in ["ibtracs","nasa_glc","desinventar","cap"])
    status["coverage_claim_gate"] = ("Global physical-event coverage analyses are allowed" if status["coverage_ready"]
                                     else "Blocked: do not report global coverage analyses")
    status["communication_claim_gate"] = ("External communication-response estimates are allowed" if status["model_ready"]
                                          else "Blocked: do not report external communication-response estimates")
    (OUT / "data_quality_audit.json").write_text(json.dumps(status, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(status, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
