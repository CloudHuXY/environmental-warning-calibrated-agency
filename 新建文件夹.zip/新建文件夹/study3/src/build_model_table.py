"""Harmonize observed disaster outcomes, CAP warnings, and physical hazards.

Every derived value is deterministic. Unmatched values remain missing. The script
never converts an unreported outcome to zero and writes a matching audit alongside
the model table.
"""
from __future__ import annotations

import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW, PROC, OUT = ROOT/"data_raw", ROOT/"data_processed", ROOT/"outputs"

SEVERITY = {"unknown":np.nan,"minor":0.25,"moderate":0.50,"severe":0.75,"extreme":1.0}
CERTAINTY = {"unknown":np.nan,"unlikely":0.20,"possible":0.40,"likely":0.70,"observed":1.0}
ACTION_WORDS = re.compile(r"\b(evacuat|shelter|avoid|leave|move|stay indoors|prepare|secure|do not|turn around|seek higher)\w*", re.I)
MECHANISM_WORDS = re.compile(r"\b(?:because|due to|caused by|results? from|saturated|storm surge|runoff|slope|landfall|rainfall)\b", re.I)

def norm_country(x): return re.sub(r"[^a-z]", "", str(x).lower())
def family(x):
    s=str(x).lower()
    if any(k in s for k in ["cyclone","hurricane","typhoon","tropical storm"]): return "storm"
    if any(k in s for k in ["landslide","mudslide","debris flow","rockfall"]): return "landslide"
    return "other"
def num(s): return pd.to_numeric(s,errors="coerce")
def hav(lat1,lon1,lat2,lon2):
    if any(pd.isna(v) for v in [lat1,lon1,lat2,lon2]): return np.nan
    p1,p2=math.radians(lat1),math.radians(lat2); dp=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 6371*2*math.asin(min(1,math.sqrt(a)))

def load_inputs():
    paths={
        "events":RAW/"desinventar_events.csv", "cap":RAW/"cap_alerts.csv",
        "tracks":PROC/"ibtracs_track_points_2007_2025.csv",
        "storms":PROC/"ibtracs_storm_events_2007_2025.csv",
        "landslides":PROC/"nasa_landslide_events_2007_2025.csv"}
    missing=[str(p) for p in paths.values() if not p.exists()]
    if missing: return None, paths, missing
    return {k:pd.read_csv(p,low_memory=False) for k,p in paths.items()}, paths, []

def prepare_events(d):
    required=["event_id","event_date","country","hazard_type","deaths","affected","evacuated"]
    miss=[c for c in required if c not in d]
    if miss: raise ValueError(f"desinventar_events.csv missing columns: {miss}")
    x=d.copy(); x["event_date"]=pd.to_datetime(x.event_date,errors="coerce",utc=True)
    x=x[x.event_date.dt.year.between(2007,2025)].copy()
    x["country_key"]=x.country.map(norm_country); x["hazard_family"]=x.hazard_type.map(family)
    for c in ["latitude","longitude","deaths","affected","evacuated","loss_usd","action_taken","evacuated_reporting_complete",
              "exposed_population","road_density","housing_vulnerability","rainfall_mm","slope_deg"]:
        if c not in x: x[c]=np.nan
        x[c]=num(x[c])
    # An explicit action observation takes priority. Evacuation counts are usable only
    # when the export marks reporting for that field complete.
    x["target_action"]=np.where(x.action_taken.isin([0,1]),x.action_taken,
        np.where((x.evacuated_reporting_complete==1)&x.evacuated.notna(),(x.evacuated>0).astype(float),np.nan))
    return x

def prepare_cap(d):
    required=["alert_id","sent_time","country","event","severity","urgency","certainty","area_description","instruction"]
    miss=[c for c in required if c not in d]
    if miss: raise ValueError(f"cap_alerts.csv missing columns: {miss}")
    x=d.copy(); x["sent_time"]=pd.to_datetime(x.sent_time,errors="coerce",utc=True)
    x["country_key"]=x.country.map(norm_country); x["hazard_family"]=x.event.map(family)
    x["severity_score"]=x.severity.astype(str).str.lower().map(SEVERITY)
    x["certainty_score"]=x.certainty.astype(str).str.lower().map(CERTAINTY)
    text=x.instruction.fillna("").astype(str)
    desc=x.area_description.fillna("").astype(str)
    x["instruction_word_count"]=text.str.findall(r"\b\w+\b").str.len()
    x["action_specificity"]=text.str.findall(ACTION_WORDS).str.len().clip(upper=5)/5
    x["mechanism_explanation"]=(text.str.contains(MECHANISM_WORDS)|desc.str.contains(MECHANISM_WORDS)).astype(int)
    for c in ["latitude","longitude"]:
        if c not in x: x[c]=np.nan
        x[c]=num(x[c])
    if "map_present" not in x:
        polygon=x["polygon"].notna() if "polygon" in x else pd.Series(False,index=x.index)
        map_url=x["map_url"].notna() if "map_url" in x else pd.Series(False,index=x.index)
        x["map_present"]=(polygon|map_url).astype(int)
    else: x["map_present"]=num(x.map_present)
    return x

def warning_features(events, cap):
    rows=[]
    for _,e in events.iterrows():
        cand=cap[(cap.country_key==e.country_key)&(cap.hazard_family==e.hazard_family)].copy()
        cand["lead_hours"]=(e.event_date-cand.sent_time).dt.total_seconds()/3600
        cand=cand[cand.lead_hours.between(0,168)]
        if pd.notna(e.latitude) and pd.notna(e.longitude) and len(cand):
            cand["alert_distance_km"]=[hav(e.latitude,e.longitude,a,b) for a,b in zip(cand.latitude,cand.longitude)]
            geo=cand[cand.alert_distance_km.isna()|cand.alert_distance_km.le(1000)]
            if len(geo): cand=geo
        if cand.empty:
            rows.append({"event_id":e.event_id,"cap_match_count":0}); continue
        first=cand.sort_values("sent_time").iloc[0]
        rows.append({"event_id":e.event_id,"cap_match_count":len(cand),"lead_hours":cand.lead_hours.max(),
            "severity_score":cand.severity_score.max(),"certainty_score":cand.certainty_score.max(),
            "instruction_word_count":cand.instruction_word_count.max(),"mechanism_explanation":cand.mechanism_explanation.max(),
            "map_present":cand.map_present.max(),"action_specificity":cand.action_specificity.max(),
            "matched_alert_id":first.alert_id})
    return pd.DataFrame(rows)

def storm_features(events, tracks, storms):
    tracks["time"]=pd.to_datetime(tracks.time,errors="coerce",utc=True)
    byid=storms.set_index("storm_id",drop=False); rows=[]
    for _,e in events.iterrows():
        if e.hazard_family!="storm": rows.append({"event_id":e.event_id}); continue
        sid=str(e.get("storm_id","")); chosen=None; dist=np.nan
        if sid and sid!="nan" and sid in byid.index: chosen=byid.loc[sid]
        else:
            c=tracks[(tracks.time-e.event_date).abs()<=pd.Timedelta(days=3)].copy()
            if pd.notna(e.latitude) and pd.notna(e.longitude) and len(c):
                c["d"]=[hav(e.latitude,e.longitude,a,b) for a,b in zip(c.lat,c.lon)]; c=c[c.d<=1000]
            if len(c):
                p=c.sort_values("d" if "d" in c else "time").iloc[0]; sid=str(p.storm_id); dist=p.get("d",np.nan)
                if sid in byid.index: chosen=byid.loc[sid]
        if chosen is None: rows.append({"event_id":e.event_id}); continue
        if isinstance(chosen,pd.DataFrame): chosen=chosen.iloc[0]
        rows.append({"event_id":e.event_id,"matched_storm_id":sid,"distance_to_hazard_km":dist,
                     "max_wind_kt":chosen.get("max_wind_kt",np.nan),"min_pressure_mb":chosen.get("min_pressure_mb",np.nan)})
    return pd.DataFrame(rows)

def landslide_features(events, lands):
    lands["event_date"]=pd.to_datetime(lands.event_date,errors="coerce",utc=True); rows=[]
    for _,e in events.iterrows():
        if e.hazard_family!="landslide": rows.append({"event_id":e.event_id}); continue
        c=lands[(lands.event_date-e.event_date).abs()<=pd.Timedelta(days=3)].copy()
        if pd.notna(e.latitude) and pd.notna(e.longitude) and len(c):
            c["d"]=[hav(e.latitude,e.longitude,a,b) for a,b in zip(c.latitude,c.longitude)]; c=c[c.d<=200]
        if c.empty: rows.append({"event_id":e.event_id}); continue
        p=c.sort_values("d" if "d" in c else "event_date").iloc[0]
        rows.append({"event_id":e.event_id,"matched_landslide_id":p.event_id,"distance_to_hazard_km":p.get("d",np.nan),
                     "nasa_reported_fatalities":p.get("fatalities",np.nan)})
    return pd.DataFrame(rows)

def main():
    PROC.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    data,paths,missing=load_inputs()
    if missing:
        status={"status":"blocked","missing_inputs":missing,"results_written":False}
        (OUT/"harmonization_status.json").write_text(json.dumps(status,indent=2),encoding="utf-8"); print(json.dumps(status,indent=2)); return 0
    ev=prepare_events(data["events"]); cap=prepare_cap(data["cap"])
    out=ev.merge(warning_features(ev,cap),on="event_id",how="left")
    out=out.merge(storm_features(ev,data["tracks"],data["storms"]),on="event_id",how="left",suffixes=("","_storm"))
    out=out.merge(landslide_features(ev,data["landslides"]),on="event_id",how="left",suffixes=("","_landslide"))
    out=out.sort_values("event_date")
    out["prior_warning_count"]=out.groupby(["country_key","hazard_family"])["cap_match_count"].transform(lambda s:s.shift().rolling(20,min_periods=1).sum())
    # Comparable 0-1 observed intensity is computed within hazard family.
    storm_rank=out.groupby("hazard_family")["max_wind_kt"].rank(pct=True)
    rain_rank=out.groupby("hazard_family")["rainfall_mm"].rank(pct=True)
    observed=np.where(out.hazard_family.eq("storm"),storm_rank,rain_rank)
    out["forecast_outcome_gap"]=np.where(out.severity_score.notna()&pd.notna(observed),np.abs(out.severity_score-observed),np.nan)
    out["gap_x_explanation"]=out.forecast_outcome_gap*out.mechanism_explanation
    out.to_csv(PROC/"global_event_model.csv",index=False)
    audit={"status":"complete","created_at_utc":datetime.now(timezone.utc).isoformat(),"rows":len(out),
           "countries":int(out.country.nunique()),"hazard_counts":out.hazard_family.value_counts(dropna=False).to_dict(),
           "target_action_observed":int(out.target_action.notna().sum()),"cap_match_rate":float(out.cap_match_count.fillna(0).gt(0).mean()),
           "storm_match_rate":float(out.loc[out.hazard_family.eq('storm'),'matched_storm_id'].notna().mean()) if out.hazard_family.eq('storm').any() else None,
           "landslide_match_rate":float(out.loc[out.hazard_family.eq('landslide'),'matched_landslide_id'].notna().mean()) if out.hazard_family.eq('landslide').any() else None,
           "claim_gate":"Model fitting still applies sample-size and outcome-observation gates"}
    (OUT/"harmonization_status.json").write_text(json.dumps(audit,indent=2,default=str),encoding="utf-8"); print(json.dumps(audit,indent=2,default=str))
    return 0
if __name__=="__main__": raise SystemExit(main())
