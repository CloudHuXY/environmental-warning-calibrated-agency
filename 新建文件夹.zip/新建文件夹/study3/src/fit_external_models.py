"""Fit externally validated EHMRF model ladder from harmonized observed events.

No results are produced unless the input passes the claim gate. The implementation
uses deterministic grouped cross-validation and a NumPy logistic regression so it
can run in the bundled workspace Python without external ML packages.
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data_processed" / "global_event_model.csv"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"

MODEL_BLOCKS = {
    "M0_intercept": [],
    "M1_hazard": ["max_wind_kt", "rainfall_mm", "slope_deg", "distance_to_hazard_km"],
    "M2_exposure": ["max_wind_kt", "rainfall_mm", "slope_deg", "distance_to_hazard_km",
                    "exposed_population", "road_density", "housing_vulnerability"],
    "M3_warning": ["max_wind_kt", "rainfall_mm", "slope_deg", "distance_to_hazard_km",
                   "exposed_population", "road_density", "housing_vulnerability",
                   "lead_hours", "severity_score", "certainty_score", "instruction_word_count",
                   "mechanism_explanation", "map_present", "action_specificity"],
    "M4_ehmrf": ["max_wind_kt", "rainfall_mm", "slope_deg", "distance_to_hazard_km",
                 "exposed_population", "road_density", "housing_vulnerability",
                 "lead_hours", "severity_score", "certainty_score", "instruction_word_count",
                 "mechanism_explanation", "map_present", "action_specificity",
                 "forecast_outcome_gap", "prior_warning_count", "gap_x_explanation"],
}
POST_OUTCOME_LEAKAGE = {"deaths", "fatalities", "injuries", "affected", "loss_usd", "damage", "target"}


def sigmoid(x):
    x = np.clip(x, -30, 30)
    return 1.0 / (1.0 + np.exp(-x))


def fit_logit(x, y, ridge=1e-5, max_iter=100):
    beta = np.zeros(x.shape[1])
    penalty = np.eye(x.shape[1]) * ridge; penalty[0, 0] = 0
    for _ in range(max_iter):
        p = sigmoid(x @ beta)
        w = np.clip(p * (1 - p), 1e-6, None)
        h = x.T @ (x * w[:, None]) + penalty
        score = x.T @ (y - p) - penalty @ beta
        step = np.linalg.solve(h, score)
        beta += step
        if np.max(np.abs(step)) < 1e-7:
            break
    return beta


def auc(y, p):
    y = np.asarray(y, int); p = np.asarray(p, float)
    n1, n0 = int(y.sum()), int((1-y).sum())
    if n1 == 0 or n0 == 0: return float("nan")
    ranks = pd.Series(p).rank(method="average").to_numpy()
    return float((ranks[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def metrics(y, p):
    p = np.clip(np.asarray(p, float), 1e-8, 1-1e-8); y=np.asarray(y, int)
    return {"auc": auc(y,p), "brier": float(np.mean((p-y)**2)),
            "log_loss": float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p)))}


def prepare(train, test, features):
    if not features:
        return np.ones((len(train),1)), np.ones((len(test),1)), ["intercept"]
    xtr=train[features].apply(pd.to_numeric,errors="coerce").copy()
    xte=test[features].apply(pd.to_numeric,errors="coerce").copy()
    med=xtr.median(); xtr=xtr.fillna(med); xte=xte.fillna(med)
    mean=xtr.mean(); sd=xtr.std(ddof=0).replace(0,1)
    xtr=(xtr-mean)/sd; xte=(xte-mean)/sd
    return np.column_stack([np.ones(len(xtr)),xtr.to_numpy(float)]), np.column_stack([np.ones(len(xte)),xte.to_numpy(float)]), ["intercept",*features]


def grouped_predictions(df, target, group, features):
    pred=pd.Series(np.nan,index=df.index,dtype=float); fold=[]
    for value in sorted(df[group].dropna().astype(str).unique()):
        test=df[group].astype(str)==value; train=~test
        if test.sum()<10 or train.sum()<100 or df.loc[train,target].nunique()<2:
            continue
        xtr,xte,_=prepare(df.loc[train],df.loc[test],features)
        beta=fit_logit(xtr,df.loc[train,target].to_numpy(int))
        pred.loc[test]=sigmoid(xte@beta)
        fold.append({"group":value,"n":int(test.sum()),**metrics(df.loc[test,target],pred.loc[test])})
    return pred,fold


def calibration(y,p,bins=10):
    frame=pd.DataFrame({"y":y,"p":p}).dropna().sort_values("p")
    frame["bin"]=pd.qcut(frame["p"],q=min(bins,len(frame)),duplicates="drop")
    return frame.groupby("bin",observed=True).agg(n=("y","size"),predicted=("p","mean"),observed=("y","mean")).reset_index(drop=True)


def calibration_svg(cal, path):
    w,h=1000,760; L,R,T,B=110,50,90,100; pw=w-L-R; ph=h-T-B
    def xx(v): return L+float(v)*pw
    def yy(v): return T+(1-float(v))*ph
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">',
           '<rect width="100%" height="100%" fill="white"/>',
           '<style>text{font-family:Arial;fill:#17212B}.t{font-size:28px;font-weight:700}.a{font-size:18px}.n{font-size:15px;fill:#5B6570}</style>',
           '<text x="70" y="50" class="t">EHMRF held-out calibration</text>',
           f'<line x1="{L}" y1="{yy(0)}" x2="{xx(1)}" y2="{yy(1)}" stroke="#9AA4AE" stroke-width="3" stroke-dasharray="8 7"/>',
           f'<line x1="{L}" y1="{T}" x2="{L}" y2="{h-B}" stroke="#222" stroke-width="2"/>',
           f'<line x1="{L}" y1="{h-B}" x2="{w-R}" y2="{h-B}" stroke="#222" stroke-width="2"/>']
    for _,r in cal.iterrows():
        parts.append(f'<circle cx="{xx(r.predicted):.1f}" cy="{yy(r.observed):.1f}" r="9" fill="#235789"/>')
    parts += [f'<text x="{L+pw/2}" y="{h-35}" text-anchor="middle" class="a">Predicted probability</text>',
              f'<text x="28" y="{T+ph/2}" transform="rotate(-90 28 {T+ph/2})" text-anchor="middle" class="a">Observed proportion</text>',
              '<text x="70" y="725" class="n">Each point is an equal-frequency bin from grouped held-out predictions.</text>','</svg>']
    path.write_text("\n".join(parts),encoding="utf-8")


def main():
    OUT.mkdir(parents=True,exist_ok=True); FIG.mkdir(parents=True,exist_ok=True)
    if not DATA.exists():
        status={"status":"blocked","reason":f"missing harmonized observed-event table: {DATA}","results_written":False}
        (OUT/"model_status.json").write_text(json.dumps(status,indent=2),encoding="utf-8"); print(json.dumps(status,indent=2)); return 0
    df=pd.read_csv(DATA,low_memory=False)
    required={"event_id","country","target_action"}
    missing=sorted(required-set(df.columns))
    if missing: raise ValueError(f"missing required columns: {missing}")
    df["target_action"]=pd.to_numeric(df["target_action"],errors="coerce")
    df=df[df["target_action"].isin([0,1])].copy()
    if len(df)<500 or df["country"].nunique()<4 or df["target_action"].nunique()<2:
        raise ValueError("claim gate failed: require >=500 observed events, >=4 countries, and both target classes")
    full_required=MODEL_BLOCKS["M4_ehmrf"]
    missing_full=sorted(set(full_required)-set(df.columns))
    sparse_full=sorted(f for f in full_required if f in df.columns and df[f].notna().mean()<0.20)
    if missing_full or sparse_full:
        status={"status":"blocked","reason":"full EHMRF feature gate failed",
                "missing_features":missing_full,"features_below_20pct_observed":sparse_full,
                "results_written":False}
        (OUT/"model_status.json").write_text(json.dumps(status,indent=2),encoding="utf-8")
        print(json.dumps(status,indent=2)); return 0
    results=[]; all_predictions=[]
    for model,features in MODEL_BLOCKS.items():
        missing_features=sorted(set(features)-set(df.columns))
        if missing_features:
            results.append({"model":model,"status":"skipped_missing_features","missing_requested_features":missing_features})
            continue
        available=features
        illegal=sorted(set(available)&POST_OUTCOME_LEAKAGE)
        if illegal: raise ValueError(f"post-outcome leakage features detected: {illegal}")
        pred,folds=grouped_predictions(df,"target_action","country",available)
        keep=pred.notna(); overall=metrics(df.loc[keep,"target_action"],pred[keep])
        results.append({"model":model,"status":"complete","n":int(keep.sum()),"features":available,"missing_requested_features":[],**overall,"folds":folds})
        all_predictions.append(pd.DataFrame({"event_id":df.loc[keep,"event_id"],"model":model,"observed":df.loc[keep,"target_action"],"predicted":pred[keep]}))
    receipt={"status":"complete","created_at_utc":datetime.now(timezone.utc).isoformat(),"input":str(DATA),"models":results}
    (OUT/"external_model_results.json").write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding="utf-8")
    pd.concat(all_predictions).to_csv(OUT/"held_out_predictions.csv",index=False)
    if not all_predictions or results[-1].get("model") != "M4_ehmrf" or results[-1].get("status") != "complete":
        raise ValueError("full EHMRF model was not estimable; calibration figure withheld")
    best=all_predictions[-1]; cal=calibration(best["observed"],best["predicted"]); cal.to_csv(OUT/"ehmrf_calibration.csv",index=False)
    calibration_svg(cal,FIG/"Figure_Study3_Calibration.svg")
    (OUT/"model_status.json").write_text(json.dumps({"status":"complete","results_written":True},indent=2),encoding="utf-8")
    print(json.dumps({"status":"complete","models":[r for r in results]},indent=2))


if __name__=="__main__": main()
