"""Insert verified Study 3A coverage results into the conference manuscript."""
from pathlib import Path
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/"outputs"/"Environmental_Health_Message_Lab_A_Conference_Revision.docx"
TARGET=ROOT/"outputs"/"Environmental_Health_Message_Lab_A_Conference_Global_Coverage.docx"
FIG=ROOT/"study3"/"figures"/"Figure_Study3A_GlobalCoverage.png"

def find(doc,text):
    matches=[p for p in doc.paragraphs if p.text.strip()==text]
    if len(matches)!=1: raise ValueError(f"expected one paragraph {text!r}, found {len(matches)}")
    return matches[0]

def main():
    d=Document(SOURCE)
    abstract=d.paragraphs[4]
    anchor="A linked measurement, trust-update, and action model improved held-out-region prediction over a risk-perception-only benchmark."
    addition=(anchor+" A separate public-data audit located the experimental hazards within 1,952 tropical-cyclone events across six named basins and 10,988 reported landslides across 141 named countries; this audit establishes event-space coverage rather than behavioral representativeness.")
    if anchor not in abstract.text: raise ValueError("abstract anchor changed")
    abstract.text=abstract.text.replace(anchor,addition)

    contribution=d.paragraphs[11]
    contribution.text += (" A source-audited global coverage analysis further distinguishes hazard-domain breadth from evidence about public response, preventing physical event occurrence from being used as a behavioral proxy.")

    discussion=find(d,"6 Discussion")
    h=discussion.insert_paragraph_before("5.5 Study 3A: global physical-event coverage")
    h.style="Heading 2"
    p=discussion.insert_paragraph_before(
        "A preregistered behavioral transport test requires harmonized warning and action outcomes, which are not supplied by global physical-hazard catalogs. We therefore used Study 3A for the narrower purpose of auditing hazard-domain coverage. After removing spur tracks and restricting seasons to 2007–2025, IBTrACS contained 1,952 unique tropical-cyclone events and 117,808 six-hourly track points. Six basins were explicitly named; 331 events had no basin code in the downloaded field and were retained as missing rather than reassigned. The median reported maximum wind was 60 kt among the 1,821 storms with a numeric wind estimate."
    )
    p.style="Normal"
    p=discussion.insert_paragraph_before(
        "The downloaded NASA Global Landslide Catalog contributed 10,988 reports dated from 2007 through 28 September 2017, including 9,603 records with a reported fatality count and 141 named countries. The map shows broad hazard-space coverage but also visible source concentration. The catalog ends in 2017, so later zeros in the annual panel indicate absent source coverage rather than absent landslides. These records support descriptive global scope and selection of transport cases; they cannot estimate comprehension, trust, or protective action."
    )
    p.style="Normal"
    pic=discussion.insert_paragraph_before()
    pic.alignment=WD_ALIGN_PARAGRAPH.CENTER
    pic.add_run().add_picture(str(FIG),width=Inches(6.75))
    cap=discussion.insert_paragraph_before("Figure 7. Global coverage of IBTrACS tropical-cyclone tracks and NASA Global Landslide Catalog reports. Point density reflects both hazard occurrence and source coverage; the NASA export ends in 2017.")
    cap.alignment=WD_ALIGN_PARAGRAPH.CENTER
    cap.style="Caption" if "Caption" in [s.name for s in d.styles] else "Normal"

    lim=find(d,"Several limitations constrain the conclusions. The experiments used fictional scenarios and measured immediate decisions rather than behavior during an unfolding emergency. The six broad regions increase heterogeneity but do not constitute probability samples of all residents within those regions. Most responses were completed in English, so language and region are not fully separable. Country-level institutional systems, hazard familiarity, disability, access to transport, and material constraints may change whether understanding can be converted into action. The behavioral outcomes therefore estimate decision quality under controlled information, not evacuation rates in a real disaster.")
    lim.text += (" Study 3A broadens the physical event domain but does not repair this behavioral limitation. IBTrACS contains no public-response measure, and the NASA catalog is affected by media and reporting selection and ends in 2017 in the downloaded export.")

    nexttests=find(d,"The remaining confirmatory analyses are substantive. Measurement invariance must be established before regional means are compared. H4 and H8 require participant-level indirect-effect estimation with uncertainty intervals. Predictive claims require the complete model ladder, ablations, fold-level uncertainty, and calibration. Study 2 requires a component-controlled replication that holds probability, evidence strength, action instructions, visual prominence, and length constant while randomizing only the forecast-revision explanation. Additional hazards are required for a cross-hazard transport test.")
    nexttests.text += (" The next observational extension will link FEMA IPAWS warnings to NOAA Storm Events and IBTrACS intensity records. That linkage is designed as an incremental prediction test; confounding prevents a causal interpretation of warning coefficients.")

    conclusion=find(d,"Across two environmental-hazard experiments, causal explanation improved understanding of a debris-flow mechanism, a risk map improved spatial interpretation, and an enhanced follow-up warning package increased trust and protective action after a typhoon-warning expectation gap. The first study identifies representation effects; the second identifies a package effect that still requires component-level decomposition. Together they support continued testing of a model in which comprehension and calibrated trust connect environmental evidence to action. Strong claims of mediation, explanation-specific repair, global representativeness, and cross-hazard transport await the prespecified analyses and controlled replication described here.")
    conclusion.text=conclusion.text.replace("Together they support", "A separate audit demonstrates that the hazard framework spans a large global event space while leaving behavioral transport untested. Together the studies support")

    d.add_paragraph("National Aeronautics and Space Administration. (2017). Global Landslide Catalog Export. https://data.nasa.gov/dataset/global-landslide-catalog-export-f07b6")
    d.add_paragraph("National Centers for Environmental Information. (2025). International Best Track Archive for Climate Stewardship (IBTrACS), version 4 revision 1. https://doi.org/10.25921/82ty-9e16")
    d.save(TARGET)
    print(TARGET)

if __name__=="__main__": main()
