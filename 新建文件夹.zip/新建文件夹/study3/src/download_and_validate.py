"""Download public Study 3 inputs and write immutable source receipts.

The script never fabricates or fills source records. Existing raw files are left
untouched unless --force is supplied. Downloads are streamed to a temporary file,
hashed, and moved into data_raw only after basic validation succeeds.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
import tempfile
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data_raw"
OUT = ROOT / "outputs"
SOURCES = {
    "ibtracs": {
        "url": "https://www.ncei.noaa.gov/data/international-best-track-archive-for-climate-stewardship-ibtracs/v04r01/access/csv/ibtracs.since1980.list.v04r01.csv",
        "filename": "ibtracs.since1980.list.v04r01.csv",
        "required_columns": {"SID", "SEASON", "BASIN", "ISO_TIME", "LAT", "LON"},
    },
    "nasa_glc": {
        "url": "https://data.nasa.gov/docs/legacy/Global_Landslide_Catalog_Export/Global_Landslide_Catalog_Export_rows.csv",
        "filename": "Global_Landslide_Catalog_Export_rows.csv",
        "required_any": [{"event_id", "id"}, {"latitude", "lat"}, {"longitude", "lon", "lng"}],
    },
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalized_columns(path: Path) -> list[str]:
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
        row = next(csv.reader(f))
    return [x.strip().lower() for x in row]


def validate_header(source_id: str, path: Path) -> dict:
    cols = normalized_columns(path)
    spec = SOURCES[source_id]
    result = {"columns": cols, "header_valid": True, "problems": []}
    required = {x.lower() for x in spec.get("required_columns", set())}
    missing = sorted(required - set(cols))
    if missing:
        result["header_valid"] = False
        result["problems"].append(f"missing required columns: {missing}")
    for alternatives in spec.get("required_any", []):
        if not ({x.lower() for x in alternatives} & set(cols)):
            result["header_valid"] = False
            result["problems"].append(f"missing one of: {sorted(alternatives)}")
    return result


def download_one(source_id: str, force: bool = False) -> dict:
    spec = SOURCES[source_id]
    RAW.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    destination = RAW / spec["filename"]
    if destination.exists() and not force:
        validation = validate_header(source_id, destination)
        return {
            "source_id": source_id,
            "status": "existing",
            "path": str(destination),
            "bytes": destination.stat().st_size,
            "sha256": sha256(destination),
            **validation,
        }
    fd, tmp_name = tempfile.mkstemp(prefix=source_id + "_", suffix=".part", dir=RAW)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        req = urllib.request.Request(spec["url"], headers={"User-Agent": "EHMRF-Study3/1.0"})
        with urllib.request.urlopen(req, timeout=120) as response, tmp.open("wb") as out:
            shutil.copyfileobj(response, out, length=1024 * 1024)
        if tmp.stat().st_size < 1000:
            raise ValueError("downloaded file is unexpectedly small")
        validation = validate_header(source_id, tmp)
        if not validation["header_valid"]:
            raise ValueError("; ".join(validation["problems"]))
        if destination.exists():
            destination.unlink()
        tmp.replace(destination)
        return {
            "source_id": source_id,
            "status": "downloaded",
            "url": spec["url"],
            "path": str(destination),
            "bytes": destination.stat().st_size,
            "sha256": sha256(destination),
            **validation,
        }
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        return {"source_id": source_id, "status": "failed", "url": spec["url"], "error": repr(exc)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["all", *SOURCES], default="all")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    ids = list(SOURCES) if args.source == "all" else [args.source]
    receipt = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "results": [download_one(i, args.force) for i in ids],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "download_receipt.json"
    path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(receipt, indent=2, ensure_ascii=False))
    return 0 if all(r["status"] in {"downloaded", "existing"} and r.get("header_valid") for r in receipt["results"]) else 2


if __name__ == "__main__":
    raise SystemExit(main())

