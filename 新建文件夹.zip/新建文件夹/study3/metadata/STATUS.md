# Study 3 pipeline status

**Current state:** Study 3A is ready. The supplied IBTrACS and NASA files passed integrity and schema checks, and source-backed coverage tables and a global figure have been produced. Study 3B remains pending because the local runtime blocks outbound downloads of the FEMA and NOAA archives.

The download attempt and exact errors are recorded in `download_receipt.json`. The analysis claim gates are recorded in `data_quality_audit.json`, `harmonization_status.json`, and `model_status.json`.

## Ready components

- fixed official-source registry and global case bank;
- streamed downloads with temporary-file validation and SHA-256 receipts;
- schema, date, duplicate, missingness, and coverage audits;
- IBTrACS storm-event and track-point preparation;
- NASA landslide-event preparation;
- deterministic CAP-to-impact and hazard-to-impact matching;
- protected treatment of unreported action outcomes as missing;
- prespecified M0–M4 model ladder with country-held-out prediction;
- AUC, Brier score, log loss, and calibration output;
- leakage checks and claim gates.

## Study 3B inputs still required

The preferred replacement for manual DesInventar/CAP exports is now FEMA IPAWS plus NOAA Storm Events. The automated downloader is `../src/download_us_official_archives.py`; see `../STUDY3_DESIGN_DECISION.md`. No additional manual data assembly is requested from the participant researcher.

After the inputs are present, run `python ../src/run_all.py` from this directory or `python src/run_all.py` from the Study 3 directory.
