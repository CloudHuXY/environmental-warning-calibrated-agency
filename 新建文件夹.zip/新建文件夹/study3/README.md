# Study 3: Global event-level external validation

This folder contains two linked analyses. Study 3A describes the global physical-event coverage of IBTrACS and the NASA Global Landslide Catalog. Study 3B is a separate external communication-response validation that runs only if defensible warning and observed-action records are supplied. It does not generate or fill participant responses.

Study 3A may run with only the two fixed public datasets. Study 3B requires the DesInventar-style impact table and CAP warning table described below. The two claim gates remain separate so physical-event coverage is not presented as evidence of public behavior.

After the source audit, the preferred Study 3B route is the reproducible U.S. official-archive linkage described in `STUDY3_DESIGN_DECISION.md`. `src/download_us_official_archives.py` retrieves FEMA IPAWS CAP alerts and NOAA Storm Events detail files without requiring manual DesInventar or CAP exports. The older generic DesInventar/CAP interface remains available for later multi-country extensions.

## Source files

Put the four files listed in `data_raw/PLACE_FILES_HERE.md` into `data_raw/`. The two fixed public datasets can be fetched by running:

```powershell
python src/download_and_validate.py
```

`desinventar_events.csv` must contain one observed impact record per row:

| Column | Meaning |
|---|---|
| `event_id` | Stable unique identifier |
| `event_date` | ISO date or timestamp |
| `country` | Country name |
| `hazard_type` | Original hazard label |
| `deaths`, `affected`, `evacuated` | Outcomes; blank means unreported |
| `latitude`, `longitude` | Event centroid when available |
| `action_taken` | Optional observed binary protective action |
| `evacuated_reporting_complete` | `1` only when a reported zero means zero rather than missing |
| `storm_id` | Optional IBTrACS SID for deterministic storm linkage |
| `loss_usd`, `exposed_population`, `road_density`, `housing_vulnerability`, `rainfall_mm`, `slope_deg` | Optional covariates |

`cap_alerts.csv` must contain one authoritative alert per row:

| Column | Meaning |
|---|---|
| `alert_id`, `sent_time`, `country`, `event` | Identifier, ISO issue time, country, hazard label |
| `severity`, `urgency`, `certainty` | CAP categories |
| `area_description`, `instruction` | Public-facing warning fields |
| `latitude`, `longitude` | Alert-area centroid when available |
| `polygon`, `map_url`, `map_present` | Optional map evidence |

The pipeline treats an unreported outcome as missing. It derives `target_action` only from an explicit binary `action_taken`, or from `evacuated` when `evacuated_reporting_complete=1`.

## Run

```powershell
python src/run_all.py
```

The steps verify schemas and file hashes, prepare storm and landslide features, match alerts to events by country/hazard/time and then geography when coordinates exist, and run country-held-out prediction. `outputs/data_quality_audit.json`, `outputs/harmonization_status.json`, and `outputs/model_status.json` are claim gates. A missing file, incomplete schema, insufficient observed action outcomes, or fewer than four countries prevents reportable model estimates.

The full model requires all prespecified feature blocks. A missing feature skips that model; it is not silently replaced with a smaller model. Deaths, affected persons, and losses are outcomes and are excluded from predictors to prevent post-outcome leakage.

## Interpretation limits

IBTrACS describes physical storm tracks rather than public behavior. The NASA catalog has reporting and media-selection bias and its core export does not cover all years through 2025. DesInventar coverage and definitions vary by country. Historical CAP availability varies with national adoption and archiving. The external analysis therefore tests transport and prediction on observed records; it does not by itself identify a causal communication effect.
