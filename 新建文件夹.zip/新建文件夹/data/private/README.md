# Participant data input

Place the verified, de-identified Qualtrics export here only after reconciling it with the immutable source export. Do not commit IP addresses, contact details, Prolific IDs, precise coordinates, or free-text identifiers. The public repository should contain only the consent-compatible analytic dataset and a checksum receipt.
