# Release checklist

- [ ] Original Qualtrics export checksum recorded
- [ ] Recruitment and exclusion flow reconciled
- [ ] Direct identifiers removed
- [ ] Consent terms permit the planned release
- [ ] Participant analyses rerun on verified data
- [x] Regional multigroup CFA completed
- [x] H4/H8 bootstrap pathway analysis completed
- [ ] Manuscript tables and figures regenerated
- [ ] GitHub release tagged and DOI archived
