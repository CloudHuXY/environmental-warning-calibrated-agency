# Environmental Warning Understanding and Calibration Model reproducibility package

This blinded pre-release package contains the questionnaire, analysis scripts, diagnostic outputs, figures, manuscript, and the public-hazard source registry for two environmental-warning experiments and a global event-coverage audit.

## Reproduction status

- Study 3A public-data coverage: reproducible from the cited NASA and NOAA source files.
- Participant-data calculations: internally reproducible from the supplied analytic workbook.
- Participant-data provenance: pending reconciliation with the original Qualtrics export.
- Cross-region measurement invariance: configural, metric, and scalar models completed; language invariance and ordinal sensitivity remain.

- H4/H8 pathway analysis: bootstrap estimates and covariate/attention sensitivities completed; causal mediation remains bounded by timing and Study 2 package confounding.

## Repository contents

- `analysis/`: data audit, mediation, predictive validation, and robustness scripts.
- `results/`: machine-readable diagnostic results and validation receipts.
- `materials/`: questionnaire and experimental materials.
- `figures/`: revised conceptual model and held-region model ladder.
- `study2_design/`: prospective component-controlled protocol, stimuli map, power decision, and design figure.
- `study3/`: source registry, case bank, processing code, and audit receipts.
- `data/private/`: instructions for adding a verified de-identified participant export.
- `manuscript/`: blinded manuscript.

## Recommended release procedure

1. Export the original Qualtrics response file with ResponseId, StartDate, EndDate, RecordedDate, Finished, Duration, consent, and attention-check fields.
2. Store the immutable raw export outside the public repository and record its SHA-256 checksum.
3. Create a de-identified analytic copy, reconcile row counts and exclusions, and rerun all scripts.
4. Replace diagnostic outputs with verified outputs, create a versioned GitHub release, and archive that release with a DOI service.
