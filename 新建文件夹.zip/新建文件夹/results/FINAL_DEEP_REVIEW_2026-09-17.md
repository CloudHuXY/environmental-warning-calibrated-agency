# Final deep review after reproducibility and robustness work

Reviewed artifact: `outputs/ICA2027_Blind_Draft_Ethics_Metadata_Updated.docx`

Reproducibility package: `outputs/Environmental_Health_Message_Lab_GitHub_Package.zip`

Status: **Needs revision**  
Completeness: **Complete for the files currently available; incomplete for source-system provenance and new-data requirements**

## Changes completed

- Recomputed all main factorial contrasts, reliability estimates, condition means, regional effects, mediation diagnostics, held-region prediction metrics, calibration, and Study 3A coverage counts.
- Verified unique participant identifiers, exact factorial coding, equal region-by-condition cells, item ranges, composite-score formulas, and preservation of the original participant columns in the metadata copy.
- Added covariate-adjusted HC3 models and attention-pass sensitivity analyses. The Study 1 interaction remains uncertain; the Study 2 package interaction remains positive.
- Re-ran the Study 3A pipeline from the local NASA and NOAA source files and reproduced 1,952 storms, 117,808 six-hourly track points, and 10,988 landslide reports in the stated date windows.
- Added a robustness and data-integrity section to the manuscript.
- Built a 53-file blinded GitHub pre-release package with scripts, materials, results, source registry, provenance statement, manifest, and release checklist. Participant data and raw IP information are excluded.
- Verified that the manuscript has blank author metadata and approximately 5,319 body words before the references.

## Paper quality

Observed-defect totals refer to the scoped inventory, not to an accuracy percentage.

| Category | Observed defects | Assessment |
|---|---:|---|
| Usefulness and completeness | 3 / 9 | The paper answers the main representation and repeated-warning questions, but formal invariance, fully confirmed mediation, and explanation-specific Study 2 evidence remain incomplete. |
| Analytical clarity | 1 / 11 | Claims are generally bounded correctly. The central empirical interpretation remains dependent on unverified participant-data provenance. |
| Visual consistency | 0 / 12 | Seven figures and five tables render cleanly, use consistent styles, and agree with the displayed calculations. |
| Venue compliance | 1 / 5 | The draft is anonymous and below the ICA 8,000-word ceiling. The provenance warning prevents submission, and final APA/template checks remain. |

## Analytical correctness and robustness

| Category | Observed defects | Assessment |
|---|---:|---|
| Source authority and confidence | 1 / 3 | NASA and NOAA sources have checksums and schema audits. The original Qualtrics export or an equivalent immutable participant-data record is absent. |
| Value accuracy | 0 / 10 | Recomputed sample sizes, condition means, contrasts, reliability, regional effects, predictive metrics, calibration, and global coverage agree with the stored outputs. |
| Figure-value agreement | 0 / 7 | Every figure reviewed agrees with its underlying table or calculation. |
| Complete source details | 1 / 3 | Public hazard sources are documented; participant source-system fields, recruitment end date, and collection-flow counts are unavailable. |
| Cross-artifact consistency | 0 / 4 | The current manuscript, audit outputs, Study 3 outputs, and GitHub package are synchronized. |
| Data-quality controls | 3 / 12 | IP/timestamps are absent, 63 attention-check failures are retained by the ITT analysis, and Study 1 has a 0.20-SD baseline imbalance. The latter two are now disclosed and covered by sensitivity analysis. |
| Conclusion support | 2 / 10 | Study 2 identifies a package rather than explanation-specific effect. The EHMRF adds almost no prediction beyond the process model in the current workbook. |

## Updated score

| Dimension | Score / 10 |
|---|---:|
| Research question and significance | 8.0 |
| Figures and tables | 8.0 |
| Writing and organization | 7.5 |
| Theory and novelty | 6.8 |
| Hypothesis development | 6.8 |
| Experimental identification | 6.3 |
| Sampling and external validity | 5.8 |
| Measurement quality | 5.4 |
| Statistical analysis | 6.2 |
| Results completeness | 5.5 |
| Transparency and reproducibility | 6.2 |
| Ethics and privacy reporting | 6.5 |
| Venue compliance | 7.2 |

Overall evidence-weighted score: **6.6 / 10**.

## Why the score cannot honestly reach 8 from the current files

1. The original workbook explicitly describes the participant records as seeded pseudo-random data and labels the participant IDs as not representing real people.
2. Researcher-attested Prolific, Qualtrics, and start-date fields were added later and cannot substitute for an original source-system export.
3. Formal multigroup CFA cannot be completed in the current runtime because no SEM engine is installed and network installation is blocked. The existing loading-congruence analysis remains a screen, not a formal invariance test.
4. Study 2 changes explanation, probability, model agreement, and message length together. No analysis can recover an explanation-only causal effect from that design.
5. The full EHMRF has almost no incremental held-region predictive value beyond the process model in the current workbook.

## Evidence required for an 8-level paper

- Reconcile an immutable Qualtrics export with participant IDs, consent, completion, timestamps, recruitment flow, exclusions, and the analytic rows; publish the resulting checksum receipt.
- Run formal configural, metric, and scalar multigroup CFA on the verified data and report fit comparisons.
- Complete the H4 and H8 indirect-effect analyses on verified data and retain bounded causal language.
- Publish a versioned repository link and archive the release with a DOI.
- For a durable score above 8, add a component-controlled Study 2 replication or independent hazard sample showing incremental EHMRF prediction.
