# Current deficiency audit and next-gate assessment — 17 September 2026

## Overall assessment

After completing regional multigroup CFA, covariate-adjusted bootstrap pathway analyses, partial identification, conference-format compression, and the telemetry-enabled Study 2R design, the current manuscript is assessed at **7.8/10**. H4 and H8 receive partial support with bounded interpretations. Study 2R is sized for 4,800 analyzable participants and now records official-map opening, dwell time, and route download, but this prospective improvement does not count as observed evidence until recruitment and analysis are complete.

## Resolved in this round

| Previous weakness | Action | Current status |
|---|---|---|
| H4 indirect effects were pending | 5,000-resample bootstrap plus covariate/region-adjusted 2,000-resample sensitivity analysis | Partial support: causal comprehension path supported; trust and scored spatial path not supported |
| H8 mechanisms were pending | Same bootstrap sequence, with package-level interpretation | Partial support: final-trust pathway stable; other pathways unstable |
| Sensitivity to attention failures was unknown | Repeated adjusted mediation in attention-pass sample | H4 causal-comprehension and H8 final-trust decisions unchanged |
| Hypothesis table did not report pathway evidence | Replaced pending rows with estimates, intervals, and bounded decisions | Resolved |
| Methods did not describe mediation uncertainty | Added resampling, covariates, regional fixed effects, and interpretation limits | Resolved |
| Study 2R power was marginal for a 10-point interaction | Expanded the analytic target from 3,200 to 4,800 | Conservative interaction power increased from approximately 81% to 93% |
| Study 2R lacked a deployment data structure | Added a Qualtrics flow, questionnaire map, blank 5,400-row import template, codebook, live audit, and a tested HC3 analysis script | Deployment-ready; participant fields remain empty until platform export |
| Conference paper was overextended | Produced a 5,366-word, 21-body-page blinded main paper and moved the global coverage audit and full Study 2R implementation to a supplement | Meets the ICA Health Communication 25-body-page rule |
| Outcomes were mainly scenario choices and intentions | Added platform-recorded official-map opening, active dwell seconds, and route-file download to Study 2R | Design resolved; observed behavioral evidence remains pending |

## Evidence now reported

| Hypothesis/path | Adjusted estimate, log-odds scale | Region-stratified bootstrap 95% CI | Decision |
|---|---:|---:|---|
| H4: EXPLAIN → causal comprehension → action | 0.273 | [0.160, 0.421] | Supported path |
| H4: EXPLAIN → trust → action | 0.016 | [−0.038, 0.081] | Not supported |
| H4: MAP → spatial correctness → action | 0.002 | [−0.067, 0.072] | Not supported |
| H8: package interaction → uncertainty understanding → action | 0.051 | [−0.007, 0.133] | Not stable |
| H8: package interaction → final trust → action | 0.235 | [0.103, 0.406] | Supported association |
| H8: package interaction → threat → action | 0.039 | [−0.0004, 0.107] | Not stable in full adjusted sample |
| H8: package interaction → efficacy → action | 0.031 | [−0.021, 0.098] | Not supported |

## Remaining deficiencies ranked by severity

### 1. Participant-data provenance — critical

The supplied workbook still self-identifies as synthetic, and the immutable Qualtrics export is absent. Internal calculations can be reproduced, but empirical provenance cannot be independently verified. This imposes the strongest submission-readiness ceiling.

**Required evidence:** immutable source export, checksum, observed recruitment flow, exclusion reconciliation, and a rerun of every participant analysis.

### 2. Study 2 component confounding — major

The completed Study 2 randomizes an enhanced package that changes explanation, stated probability, model agreement, and message length. Its total package effect is identified; the explanation-only effect is not.

**Current repair:** Study 2R is fully designed for 4,800 analyzable participants (5,400 recruitment ceiling), with the two randomized paragraphs matched at 48 words and all other warning components held fixed. Under the conservative binary-variance calculation, power is 99.8% for a 10-point explanation effect within the gap condition and 93.4% for a 10-point interaction.

**Required evidence:** conduct Study 2R and report the preregistered explanation contrast after a forecast–outcome gap.

### 3. Mediation timing — major

The supported product paths are compatible with the proposed mechanisms, but mediators and final outcomes are measured in the same postmessage period. Product-of-coefficients estimates therefore do not establish a fully sequential causal mechanism.

**Required repair:** in Study 2R, measure understanding before calibrated trust and measure action after both, or introduce a second randomization/encouragement affecting the mediator.

### 4. Ordinal measurement sensitivity — moderate

The CFA treats seven-point items as approximately continuous. Fit is strong and scalar invariance is supported across regions, but an ordinal WLSMV sensitivity analysis has not been run.

**Required repair:** rerun configural, metric, and scalar/threshold invariance in lavaan, Mplus, or an equivalent established SEM implementation.

### 5. Language invariance — moderate

Only 45 Study 1 and 39 Study 2 responses use Chinese. This is insufficient for a defensible multigroup language analysis.

**Required repair:** recruit adequate samples per language or limit the claim to regional invariance in the current predominantly English administration.

### 6. Behavioral external validation — major for an 8+ claim

Study 3A establishes broad physical-hazard coverage but has no public-response variables. It cannot validate EWUCM across hazards or predict real protective behavior.

**Required repair:** collect harmonized understanding, trust, and action outcomes for another hazard or link archived warnings to behavioral response records.

### 7. Outcome realism — moderate

The experiments measure scenario-based decisions rather than observed behavior during an unfolding disaster. This is appropriate for causal control but limits operational claims.

**Required repair:** add an incentivized information-search choice, real donation/preparation allocation, longitudinal follow-up, or field behavior measure.

## Revised scorecard

| Dimension | Score / 10 |
|---|---:|
| Research question | 8.2 |
| Figures and information design | 8.5 |
| Writing and organization | 8.4 |
| Theory and novelty | 7.7 |
| Hypotheses and research questions | 8.0 |
| Experimental design | 6.9 |
| Sampling and generalizability | 6.2 |
| Measurement | 7.2 |
| Statistical analysis | 8.2 |
| Results and evidentiary contribution | 7.8 |
| Transparency and reproducibility | 7.4 |
| Venue and format readiness | 8.4 |

The conference-facing assessment is **7.8/10** after applying a non-compensatory ceiling for unverified participant provenance and the unexecuted Study 2R. Study 2R execution and source reconciliation, rather than additional prose or formatting, remain the main gates to an A-tier score above 8.0.

## Highest-value next sequence

1. Reconcile the participant source export and rerun the complete pipeline.
2. Run ordinal WLSMV measurement-invariance sensitivity analysis.
3. Conduct Study 2R with temporally separated mediators and the platform-recorded map-opening and route-download outcomes.
4. Add a new-hazard behavioral holdout or field-linked response dataset.

The current manuscript cannot be raised honestly to 8/10 through additional prose, figures, or mathematical notation alone. The next meaningful increase requires source verification or new behavioral evidence.
