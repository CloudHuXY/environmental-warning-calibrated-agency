# Deep verification of current evidence

Original workbook SHA-256: `55f1c726733a5f161392946080c3c28742155a9a1c7ca7f3ba02f1455db44fbd`
Metadata-copy SHA-256: `9ebd34e8d85ee5e5b265616bcff579f71cd54523617f091a64b2548db6cb9ad0`

## Verified

- Participant grain: one row per participant; duplicate IDs are 0 in Study 1 and 0 in Study 2.
- Condition coding errors: 0 in Study 1 and 0 in Study 2.
- Derived-score maximum absolute error: 0.
- Metadata overlay preserved every original participant-data column: True.
- Maximum absolute baseline standardized mean difference across randomized factors: 0.202.

## Material limits

- Retained attention-check failures: 35 in Study 1 and 28 in Study 2; the analysis is therefore an all-record/ITT-style analysis unless exclusions are redefined prospectively.
- No participant IP address, response start timestamp, or response end timestamp is present in the supplied files.
- Prolific, Qualtrics, and the 2026-09-15 start date are researcher-attested metadata added after the participant table was created.
- The original workbook self-identifies as synthetic; the source-system export is absent. This blocks empirical provenance verification.

## Status

The calculations and internal table structure are reproducible. Empirical-source verification is not complete.
