# EWUCM reframing reassessment — 17 September 2026

## Decision

The reframing materially improves the paper. The central claim is now the parsimonious Environmental Warning Understanding and Calibration Model (EWUCM): causal understanding and spatial understanding are separate translation functions, and the resulting process block must improve held-region prediction over a risk-only account. Trust change and warning fatigue are treated as a dynamic extension whose value is an empirical question rather than an assumed contribution.

Current overall assessment: **7.0/10** for a selective international communication conference submission. The paper is substantially more coherent and the results contribution is no longer a 5.5-level weakness. It is still below a defensible 8/10 because three evidence gates remain unresolved: original participant-data provenance, formal multigroup CFA, and a component-controlled Study 2 replication.

## Scorecard

| Dimension | Score / 10 | Evidence and remaining constraint |
|---|---:|---|
| Research question | 8.2 | Clear environmental-health communication problem with a falsifiable prediction question. |
| Figures and information design | 8.5 | Seven publication-style figures; the revised conceptual model and model ladder communicate the argument directly. |
| Writing and organization | 7.8 | Contribution, hypotheses, model, results, and limitations now use the same core/extension distinction. |
| Theory and novelty | 7.6 | Dual causal/spatial understanding is a useful structural contribution; dynamic complexity is explicitly conditional. |
| Hypotheses and research questions | 7.3 | H10 is now aligned with the core model, and RQ1 tests incremental dynamic value. H4, H8, and H9 remain incomplete. |
| Experimental design | 6.4 | Study 1 separates explanation and map effects. Study 2 identifies a package effect but cannot isolate explanation. |
| Sampling and generalizability | 5.8 | Broad regions and held-region validation help, but probability sampling and verified recruitment flow are absent. |
| Measurement | 5.4 | Reliability is reported; formal multigroup CFA and invariance testing are still required. |
| Statistical analysis | 7.0 | Factorial contrasts, robust sensitivity checks, held-region prediction, ablations, and region-bootstrap intervals are aligned. |
| Results and evidentiary contribution | 7.2 | The core improves AUC by 0.105 over risk-only, while the dynamic extension adds approximately zero; this is a clear parsimony boundary. |
| Transparency and reproducibility | 6.5 | Scripts, machine-readable outputs, source registry, and a blinded package exist; participant-source reconciliation is pending. |
| Ethics and data governance | 6.5 | The manuscript contains a blinded ethics statement and avoids direct identifiers; documentary verification is pending. |
| Venue and format readiness | 7.4 | The draft is within the ICA general paper limit and is formatted as a complete blind manuscript. |

Unweighted mean: **7.05/10**.

## Model evidence added in this revision

Held-region comparisons use the six regional folds already reported in the analysis output.

| Comparison | Metric difference | Region-bootstrap 95% CI | Interpretation |
|---|---:|---:|---|
| EWUCM core (M3) vs risk-only (M1) | AUC +0.1053 | [0.0789, 0.1266] | Material predictive gain |
| EWUCM core (M3) vs risk-only (M1) | Brier −0.0183 | [−0.0235, −0.0121] | Better probabilistic accuracy |
| EWUCM core (M3) vs risk-only (M1) | Log loss −0.0387 | [−0.0501, −0.0255] | Better held-region fit |
| Dynamic extension (M4) vs core (M3) | AUC +0.0003 | [−0.0018, 0.0024] | No incremental value |
| Dynamic extension (M4) vs core (M3) | Brier −0.0001 | [−0.0006, 0.0004] | No incremental value |
| Dynamic extension (M4) vs core (M3) | Log loss −0.0002 | [−0.0013, 0.0009] | No incremental value |

The null M4 increment is informative because the paper now states a complexity rule in advance: retain dynamic terms only when they improve transportable prediction. It does not prove that trust updating or warning fatigue are theoretically irrelevant; it shows that they add no held-region predictive information after the core variables in the present dataset.

## Revision log

1. Renamed and redefined the model as the Environmental Warning Understanding and Calibration Model.
2. Made causal and spatial understanding the primary theoretical contribution.
3. Separated the dynamic trust-calibration extension from the core model.
4. Recast H10 as EWUCM core versus risk-only held-region prediction.
5. Added RQ1 for dynamic-extension versus core prediction.
6. Added region-bootstrap intervals for AUC, Brier score, and log loss contrasts.
7. Replaced the conceptual figure and predictive-validation figure.
8. Added the RQ1 decision to the hypothesis table and explicitly reported the negative incremental result.
9. Revised the abstract, theory, methods, discussion, limitations, and conclusion to use one consistent claim hierarchy.
10. Rendered and visually checked the complete 30-page manuscript, including figures, tables, page breaks, and repeated table headers.

## What would move the paper toward 8/10

1. Reconcile the analytic file with the immutable Qualtrics export and report the observed recruitment and exclusion flow.
2. Run the preregistered multigroup CFA sequence (configural, metric, scalar/partial scalar), report fit changes and construct reliability, and revise H9 from pending to a result.
3. Run a component-controlled follow-up experiment that holds probability, model agreement, action instructions, visual prominence, and length constant while randomizing the forecast-revision explanation.
4. Publish a versioned blinded repository and immutable archive containing the exact scripts, output receipts, materials, and consent-compatible analytic data.

With items 1, 2, and 4 completed, the package could reasonably approach **7.8/10**. A successful component-controlled replication or a preregistered external-hazard prediction test would provide the strongest basis for an **8/10 or higher** assessment.
