# CFA and Study 2R reassessment — 17 September 2026

## Current assessment

The paper now has a completed region-level configural, metric, and scalar invariance sequence for both studies, plus a prospective component-controlled Study 2R protocol. The current conference-paper package is assessed at **7.3/10**. Measurement is no longer one of the weakest dimensions; the main remaining limits are participant-data provenance, language-group sparsity, unestimated indirect effects, and the fact that Study 2R has been designed but not conducted.

## Regional multigroup CFA

The models used marker-variable identification and a mean structure. Seven-point items were treated as approximately continuous. S2A2 was reverse-scored according to the codebook before estimation. The prespecified invariance criteria were ΔCFI ≥ −.010 and ΔRMSEA ≤ +.015.

| Study | Model | CFI | RMSEA | SRMR | ΔCFI | ΔRMSEA | Decision |
|---|---|---:|---:|---:|---:|---:|---|
| Study 1 | Configural | .994 | .012 | .042 | — | — | Adequate fit |
| Study 1 | Metric | .991 | .014 | .046 | −.0024 | +.0012 | Supported |
| Study 1 | Scalar | .993 | .012 | .046 | +.0014 | −.0019 | Supported |
| Study 2 | Configural | .993 | .012 | .041 | — | — | Adequate fit |
| Study 2 | Metric | .991 | .014 | .043 | −.0025 | +.0012 | Supported |
| Study 2 | Scalar | .988 | .015 | .043 | −.0028 | +.0011 | Supported |

H9 can therefore be reported as supported across the six regional groups in the supplied analytic data. Language invariance was not estimated because the Chinese-language groups contained only 45 participants in Study 1 and 39 in Study 2. An ordinal WLSMV sensitivity analysis remains desirable for a journal version.

## Study 2R identification improvement

The replacement design is a 2 × 2 between-participants experiment:

- Forecast–outcome gap: broadly realized versus storm turning offshore.
- Causal revision explanation: absent versus present.
- Probability, model agreement, evidence strength, action instructions, timing, typography, visual prominence, paragraph position, and word count remain fixed.
- The control and explanation paragraphs contain exactly 48 words each.
- Target analytic N = 4,800, with 1,200 participants per cell; recruitment target = 5,400.
- The primary endpoint is appropriate protective action.
- The primary contrast is the explanation effect within the forecast–outcome-gap condition.

Under worst-case Bernoulli variance and two-sided α = .05, the design has approximately 98% power for a 10-percentage-point explanation effect after a gap and 81% power for a 10-point GAP × EXPLANATION interaction.

## Revised scorecard

| Dimension | Score / 10 | Change |
|---|---:|---|
| Research question | 8.2 | unchanged |
| Figures and information design | 8.5 | unchanged |
| Writing and organization | 7.8 | unchanged |
| Theory and novelty | 7.6 | unchanged |
| Hypotheses and research questions | 7.8 | H9 completed; Study 2R hypotheses preregistered |
| Experimental design | 6.4 | current Study 2 remains bundled; Study 2R raises future design quality |
| Sampling and generalizability | 5.8 | source export and probability sampling remain unresolved |
| Measurement | 7.2 | regional scalar invariance supported; language and ordinal sensitivity remain |
| Statistical analysis | 7.4 | CFA sequence and explicit Study 2R estimands added |
| Results and evidentiary contribution | 7.5 | H9 is now a result rather than pending |
| Transparency and reproducibility | 6.7 | CFA and Study 2R scripts, machine-readable files, and decisions added |
| Ethics and data governance | 6.5 | unchanged |
| Venue and format readiness | 7.4 | complete blind draft and prospective protocol |

Unweighted mean: **7.29/10**.

## What remains before an 8/10 assessment

1. Reconcile participant rows with an immutable Qualtrics export and observed exclusion flow.
2. Estimate H4 and H8 indirect effects with bootstrap or Bayesian uncertainty intervals.
3. Run an ordinal-CFA sensitivity analysis with an established SEM package.
4. Conduct Study 2R and replace the bundled package-effect claim with the preregistered explanation-only estimate.
5. Release a versioned repository and immutable archive.

Completing provenance reconciliation, mediation, and the ordinal sensitivity analysis could bring the existing paper close to 7.8. A completed Study 2R with a stable explanation effect and held-region replication would provide a credible basis for 8/10 or higher.
