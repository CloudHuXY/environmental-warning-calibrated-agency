# Provenance status

Participant recruitment platform and start date are researcher-attested. The source-system Qualtrics export is not present in this package. Participant-level analyses in `results/` are diagnostic until the verified export is reconciled and the scripts are rerun. Study 3A uses local copies of NASA Global Landslide Catalog and NOAA IBTrACS files whose checksums and schema audits are recorded in `study3/metadata/`.
