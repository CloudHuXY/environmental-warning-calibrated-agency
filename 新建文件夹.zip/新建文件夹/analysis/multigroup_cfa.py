"""Region-level multigroup CFA and measurement-invariance diagnostics.

This implementation uses normal-theory maximum likelihood with a mean structure
and a pure NumPy Adam optimizer so the analysis remains reproducible in the
bundled runtime. It fits configural, metric, and scalar models to each study.
The supplied workbook currently self-identifies as synthetic; these estimates
are diagnostic until rerun on a reconciled source-system export.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / "outputs" / "Environmental_Health_Message_Lab_模拟样本数据.xlsx"
OUT = ROOT / "analysis" / "cfa"
OUT.mkdir(parents=True, exist_ok=True)

SPECS = {
    "Study1": {
        "sheet": "Study1_Synthetic",
        "factors": {
            "causal_understanding": ["S1C1", "S1C2", "S1C3", "S1C4"],
            "calibrated_trust": ["S1T1", "S1T2", "S1T3"],
            "threat_appraisal": ["S1R1", "S1R2"],
            "response_efficacy": ["S1E1", "S1E2"],
        },
    },
    "Study2": {
        "sheet": "Study2_Synthetic",
        "factors": {
            "uncertainty_understanding": ["S2C1", "S2C2"],
            "calibrated_trust": ["S2T3", "S2T4", "S2T5"],
            "threat_appraisal": ["S2R1", "S2R2"],
            "response_efficacy": ["S2E1", "S2E2"],
            "action_intention": ["S2A1", "S2A2", "S2A3"],
        },
    },
}


def prepare(spec):
    df = pd.read_excel(BOOK, sheet_name=spec["sheet"])
    if spec["sheet"] == "Study2_Synthetic":
        # Codebook-defined reverse key before estimating the measurement model.
        df["S2A2"] = 8 - pd.to_numeric(df["S2A2"], errors="coerce")
    items, factor_index, markers = [], [], []
    for j, cols in enumerate(spec["factors"].values()):
        markers.append(len(items))
        items.extend(cols)
        factor_index.extend([j] * len(cols))
    groups = sorted(df["region"].dropna().unique().tolist())
    stats = []
    for name in groups:
        x = df.loc[df["region"].eq(name), items].apply(pd.to_numeric, errors="coerce").dropna().to_numpy(float)
        stats.append({"name": name, "n": len(x), "mean": x.mean(0), "cov": np.cov(x, rowvar=False, bias=True)})
    return items, np.asarray(factor_index), np.asarray(markers), groups, stats


def initial_state(stats, factor_index, markers, k, level):
    g, p = len(stats), len(factor_index)
    load0 = np.full(p, 0.75)
    load0[markers] = 1.0
    all_mean = np.average(np.stack([s["mean"] for s in stats]), axis=0, weights=[s["n"] for s in stats])
    state = {
        "load": np.tile(load0, (g, 1)) if level == "configural" else load0.copy(),
        "intercept": all_mean.copy() if level == "scalar" else np.stack([s["mean"] for s in stats]),
        "theta_raw": np.zeros((g, p)),
        "chol_raw": np.zeros((g, k, k)),
        "alpha": np.zeros((g, k)),
    }
    for gi, s in enumerate(stats):
        for a in range(k):
            state["chol_raw"][gi, a, a] = math.log(0.8)
        implied_common = 0.8 * load0**2
        state["theta_raw"][gi] = np.log(np.maximum(np.diag(s["cov"]) - implied_common, 0.25))
    if level == "scalar":
        # Factor-mean starting values from marker-item mean differences.
        ref = stats[0]["mean"]
        for gi, s in enumerate(stats[1:], start=1):
            state["alpha"][gi] = s["mean"][markers] - ref[markers]
    return state


def cholesky_from(raw):
    c = np.tril(raw.copy())
    idx = np.diag_indices(c.shape[0])
    c[idx] = np.exp(np.clip(c[idx], -3.0, 2.0))
    return c


def fit_model(stats, factor_index, markers, k, level, max_iter=5000, lr=0.018):
    g, p = len(stats), len(factor_index)
    n_total = sum(s["n"] for s in stats)
    state = initial_state(stats, factor_index, markers, k, level)
    m1 = {key: np.zeros_like(val) for key, val in state.items()}
    m2 = {key: np.zeros_like(val) for key, val in state.items()}
    marker_set = set(markers.tolist())
    best_value, best_state, stale = float("inf"), None, 0

    for iteration in range(1, max_iter + 1):
        grads = {key: np.zeros_like(val) for key, val in state.items()}
        value = 0.0
        for gi, s in enumerate(stats):
            load_vec = state["load"][gi] if level == "configural" else state["load"]
            load_vec = load_vec.copy(); load_vec[markers] = 1.0
            lam = np.zeros((p, k)); lam[np.arange(p), factor_index] = load_vec
            theta = np.exp(np.clip(state["theta_raw"][gi], -3.0, 3.0))
            chol = cholesky_from(state["chol_raw"][gi])
            phi = chol @ chol.T
            sigma = lam @ phi @ lam.T + np.diag(theta)
            sigma = (sigma + sigma.T) / 2 + np.eye(p) * 1e-7
            inv = np.linalg.inv(sigma)
            sign, logdet = np.linalg.slogdet(sigma)
            sign_s, logdet_s = np.linalg.slogdet(s["cov"] + np.eye(p) * 1e-9)
            if sign <= 0 or sign_s <= 0:
                raise RuntimeError("Non-positive covariance during CFA")
            nu = state["intercept"] if level == "scalar" else state["intercept"][gi]
            alpha = state["alpha"][gi] if level == "scalar" and gi > 0 else np.zeros(k)
            mu = nu + lam @ alpha
            delta = s["mean"] - mu
            cov_f = logdet + np.trace(s["cov"] @ inv) - logdet_s - p
            mean_f = float(delta @ inv @ delta)
            weight_cov = (s["n"] - 1) / n_total
            weight_mean = s["n"] / n_total
            value += weight_cov * cov_f + weight_mean * mean_f

            gcov = weight_cov * (inv - inv @ s["cov"] @ inv)
            if mean_f:
                gcov += weight_mean * (-inv @ np.outer(delta, delta) @ inv)
            gmu = weight_mean * (-2.0 * inv @ delta)
            glam = 2.0 * gcov @ lam @ phi + np.outer(gmu, alpha)
            gphi = lam.T @ gcov @ lam
            gtheta = np.diag(gcov) * theta
            gchol = (gphi + gphi.T) @ chol
            graw_chol = np.tril(gchol)
            diag = np.diag_indices(k)
            graw_chol[diag] *= np.diag(chol)
            glvec = glam[np.arange(p), factor_index]
            glvec[list(marker_set)] = 0.0
            if level == "configural": grads["load"][gi] += glvec
            else: grads["load"] += glvec
            if level == "scalar":
                grads["intercept"] += gmu
                if gi > 0: grads["alpha"][gi] += lam.T @ gmu
            else:
                grads["intercept"][gi] += gmu
            grads["theta_raw"][gi] += gtheta
            grads["chol_raw"][gi] += graw_chol

        if value < best_value - 1e-10:
            best_value = value
            best_state = {key: val.copy() for key, val in state.items()}
            stale = 0
        else:
            stale += 1

        for key in state:
            grad = np.nan_to_num(grads[key], nan=0.0, posinf=10.0, neginf=-10.0)
            grad = np.clip(grad, -10.0, 10.0)
            m1[key] = 0.9 * m1[key] + 0.1 * grad
            m2[key] = 0.999 * m2[key] + 0.001 * grad**2
            mh = m1[key] / (1 - 0.9**iteration)
            vh = m2[key] / (1 - 0.999**iteration)
            state[key] -= lr * mh / (np.sqrt(vh) + 1e-8)
        # Identification and stable parameter bounds.
        if level == "configural": state["load"][:, markers] = 1.0
        else: state["load"][markers] = 1.0
        state["load"] = np.clip(state["load"], 0.10, 2.50)
        state["theta_raw"] = np.clip(state["theta_raw"], -3.0, 3.0)
        state["intercept"] = np.clip(state["intercept"], -2.0, 9.0)
        state["alpha"] = np.clip(state["alpha"], -3.0, 3.0)
        for gi in range(g):
            state["chol_raw"][gi] = np.tril(np.clip(state["chol_raw"][gi], -2.5, 2.5))
        if iteration > 800 and stale > 500:
            break

    state = best_state
    # Recompute unscaled likelihood discrepancy and standardized residuals.
    chi, srmr_parts = 0.0, []
    for gi, s in enumerate(stats):
        load_vec = state["load"][gi] if level == "configural" else state["load"]
        load_vec = load_vec.copy(); load_vec[markers] = 1.0
        lam = np.zeros((p, k)); lam[np.arange(p), factor_index] = load_vec
        theta = np.exp(state["theta_raw"][gi]); chol = cholesky_from(state["chol_raw"][gi]); phi = chol @ chol.T
        sigma = lam @ phi @ lam.T + np.diag(theta); inv = np.linalg.inv(sigma)
        nu = state["intercept"] if level == "scalar" else state["intercept"][gi]
        alpha = state["alpha"][gi] if level == "scalar" and gi > 0 else np.zeros(k)
        delta = s["mean"] - (nu + lam @ alpha)
        _, ld = np.linalg.slogdet(sigma); _, lds = np.linalg.slogdet(s["cov"] + np.eye(p) * 1e-9)
        cov_f = ld + np.trace(s["cov"] @ inv) - lds - p
        chi += (s["n"] - 1) * cov_f + s["n"] * float(delta @ inv @ delta)
        obs_cor = s["cov"] / np.sqrt(np.outer(np.diag(s["cov"]), np.diag(s["cov"])))
        imp_cor = sigma / np.sqrt(np.outer(np.diag(sigma), np.diag(sigma)))
        tri = np.tril_indices(p, -1); srmr_parts.extend((obs_cor[tri] - imp_cor[tri]).tolist())
    q = k * (k + 1) // 2
    stats_per_group = p * (p + 3) // 2
    if level == "configural": npar = g * ((p-k) + p + q + p)
    elif level == "metric": npar = (p-k) + g * (p + q + p)
    else: npar = (p-k) + p + g * (p + q) + (g-1) * k
    df = g * stats_per_group - npar
    # Independence baseline: diagonal covariance and group-specific means.
    base_chi = 0.0
    for s in stats:
        diag = np.diag(np.diag(s["cov"])); invd = np.diag(1 / np.diag(diag))
        _, ld = np.linalg.slogdet(diag); _, lds = np.linalg.slogdet(s["cov"] + np.eye(p)*1e-9)
        base_chi += (s["n"]-1) * (ld + np.trace(s["cov"] @ invd) - lds - p)
    base_npar = g * (2*p); base_df = g * stats_per_group - base_npar
    cfi = 1 - max(chi-df, 0) / max(base_chi-base_df, chi-df, 1e-9)
    tli = 1 - ((chi/df) / (base_chi/base_df))
    rmsea = math.sqrt(max((chi-df) / (df * max(n_total-g, 1)), 0))
    return {
        "level": level, "chi_square": float(chi), "df": int(df), "cfi": float(cfi), "tli": float(tli),
        "rmsea": float(rmsea), "srmr": float(np.sqrt(np.mean(np.square(srmr_parts)))),
        "objective": float(best_value), "iterations": int(iteration), "converged": bool(stale > 500),
        "n": int(n_total), "groups": int(g), "parameters": int(npar),
    }


def main():
    all_results, rows = {}, []
    for study, spec in SPECS.items():
        items, fidx, markers, groups, stats = prepare(spec)
        models = [fit_model(stats, fidx, markers, len(spec["factors"]), level) for level in ("configural", "metric", "scalar")]
        for i, model in enumerate(models):
            model["delta_cfi"] = None if i == 0 else model["cfi"] - models[i-1]["cfi"]
            model["delta_rmsea"] = None if i == 0 else model["rmsea"] - models[i-1]["rmsea"]
            adequate = models[0]["cfi"] >= 0.90 and models[0]["rmsea"] <= 0.08 and models[0]["srmr"] <= 0.08
            model["decision"] = (
                ("adequate configural fit" if adequate else "inadequate configural fit") if i == 0 else
                "invariance supported" if adequate and model["delta_cfi"] >= -0.010 and model["delta_rmsea"] <= 0.015 else
                "small fit change but configural fit inadequate" if not adequate else
                "invariance not supported"
            )
            rows.append({"study": study, **model})
        all_results[study] = {
            "items": items, "factors": spec["factors"], "grouping": "region", "group_names": groups,
            "language_analysis": "not estimated: Chinese n below 50 in each study and only two language groups",
            "models": models,
        }
    payload = {
        "status": "DIAGNOSTIC_UNTIL_SOURCE_EXPORT_RECONCILIATION",
        "method": "normal-theory multigroup CFA with mean structure; marker-variable identification; region groups",
        "criteria": {"delta_cfi": ">= -0.010", "delta_rmsea": "<= 0.015"},
        "results": all_results,
    }
    (OUT / "multigroup_cfa_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    pd.DataFrame(rows).to_csv(OUT / "multigroup_cfa_fit.csv", index=False)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
