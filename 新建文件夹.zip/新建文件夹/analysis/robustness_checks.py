"""Covariate-adjusted and attention-pass sensitivity checks using HC3 OLS/LPM."""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / "outputs" / "Environmental_Health_Message_Lab_模拟样本数据.xlsx"
OUT = ROOT / "analysis" / "deep_verification"
OUT.mkdir(parents=True, exist_ok=True)


def design(df: pd.DataFrame, f1: str, f2: str) -> tuple[np.ndarray, list[str]]:
    cols = [np.ones(len(df)), df[f1].to_numpy(float), df[f2].to_numpy(float), (df[f1] * df[f2]).to_numpy(float)]
    names = ["intercept", f1, f2, f"{f1}_x_{f2}"]
    for c in ["age", "hazard_experience", "map_use", "numeracy_confidence", "prior_knowledge", "general_gov_trust"]:
        v = pd.to_numeric(df[c], errors="coerce").astype(float)
        v = v.fillna(v.median())
        sd = v.std(ddof=0) or 1.0
        cols.append(((v - v.mean()) / sd).to_numpy())
        names.append(c)
    for region in sorted(df.region.astype(str).unique())[1:]:
        cols.append(df.region.astype(str).eq(region).astype(float).to_numpy())
        names.append("region_" + region)
    return np.column_stack(cols), names


def hc3_fit(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    inv = np.linalg.pinv(x.T @ x)
    beta = inv @ x.T @ y
    resid = y - x @ beta
    h = np.clip(np.sum((x @ inv) * x, axis=1), 0, 0.999999)
    meat = x.T @ ((resid / (1 - h))[:, None] ** 2 * x)
    vcov = inv @ meat @ inv
    return beta, np.sqrt(np.clip(np.diag(vcov), 0, None))


def row(study: str, sample: str, outcome: str, df: pd.DataFrame, f1: str, f2: str, term: str) -> dict:
    x, names = design(df, f1, f2)
    beta, se = hc3_fit(x, pd.to_numeric(df[outcome]).to_numpy(float))
    j = names.index(term)
    z = beta[j] / se[j] if se[j] else 0.0
    p = math.erfc(abs(z) / math.sqrt(2))
    return {
        "study": study, "sample": sample, "outcome": outcome, "term": term, "n": len(df),
        "estimate": float(beta[j]), "hc3_se": float(se[j]),
        "ci_low": float(beta[j] - 1.96 * se[j]), "ci_high": float(beta[j] + 1.96 * se[j]),
        "p_normal": float(p),
    }


def main() -> None:
    s1 = pd.read_excel(BOOK, "Study1_Synthetic")
    s2 = pd.read_excel(BOOK, "Study2_Synthetic")
    s1 = s1.assign(spatial_correct=s1.S1K3.astype(str).eq("C").astype(int))
    rows = []
    for label, d in [("all_records", s1), ("attention_pass", s1[s1.attention_pass.eq(1)])]:
        rows += [
            row("Study 1", label, "comprehension_mean", d, "EXPLAIN", "MAP", "EXPLAIN"),
            row("Study 1", label, "spatial_correct", d, "EXPLAIN", "MAP", "MAP"),
            row("Study 1", label, "appropriate_action", d, "EXPLAIN", "MAP", "EXPLAIN_x_MAP"),
        ]
    for label, d in [("all_records", s2), ("attention_pass", s2[s2.attention_pass.eq(1)])]:
        rows += [
            row("Study 2", label, "post_outcome_trust", d, "GAP", "REPAIR", "GAP"),
            row("Study 2", label, "warning_fatigue", d, "GAP", "REPAIR", "GAP"),
            row("Study 2", label, "appropriate_action", d, "GAP", "REPAIR", "GAP_x_REPAIR"),
        ]
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "covariate_adjusted_robustness.csv", index=False)
    summary = {
        "method": "OLS/linear-probability models with HC3 standard errors, prespecified randomized factors, baseline covariates, and region fixed effects",
        "status": "DIAGNOSTIC UNTIL SOURCE EXPORT IS VERIFIED",
        "results": table.to_dict("records"),
    }
    (OUT / "covariate_adjusted_robustness.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
