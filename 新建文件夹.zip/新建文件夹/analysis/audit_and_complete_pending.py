"""Audit the participant workbook and run pending analyses reproducibly.

The workbook currently self-identifies as synthetic. Outputs from this script are
therefore diagnostic/demonstration results and must not be represented as observed
participant evidence unless replaced by a verified survey-platform export.
"""
from __future__ import annotations

import hashlib, json, math, zipfile
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
BOOK=ROOT/"outputs"/"Environmental_Health_Message_Lab_模拟样本数据.xlsx"
OUT=ROOT/"analysis"/"outputs"; OUT.mkdir(parents=True,exist_ok=True)
RNG=np.random.default_rng(20260916)

def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-30,30)))
def fit_logit(x,y,ridge=.05,iterations=80):
    b=np.zeros(x.shape[1]); pen=np.eye(x.shape[1])*ridge; pen[0,0]=0
    for _ in range(iterations):
        p=sigmoid(x@b); w=np.clip(p*(1-p),1e-6,None)
        h=x.T@(x*w[:,None])+pen; score=x.T@(y-p)-pen@b
        step=np.linalg.solve(h,score); b+=step
        if np.max(np.abs(step))<1e-7: break
    return b
def auc(y,p):
    y=np.asarray(y,int); p=np.asarray(p,float); n1=y.sum(); n0=len(y)-n1
    if not n1 or not n0:return np.nan
    ranks=pd.Series(p).rank(method="average").to_numpy()
    return float((ranks[y==1].sum()-n1*(n1+1)/2)/(n1*n0))
def metrics(y,p):
    p=np.clip(np.asarray(p,float),1e-8,1-1e-8); y=np.asarray(y,int)
    return {"auc":auc(y,p),"brier":float(np.mean((p-y)**2)),"log_loss":float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p)))}
def ci(a):
    a=np.asarray(a,float); a=a[np.isfinite(a)]
    return [float(np.quantile(a,.025)),float(np.quantile(a,.975))]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def provenance(s1,s2):
    with zipfile.ZipFile(BOOK) as z: members=z.namelist()
    def frame(d):
        return {"rows":len(d),"columns":len(d.columns),"duplicate_participant_ids":int(d.participant_id.duplicated().sum()),
                "missing_cells":int(d.isna().sum().sum()),"regions":d.region.value_counts().to_dict(),
                "conditions":d.condition_code.value_counts().to_dict(),"languages":d.survey_language.value_counts().to_dict(),
                "completion_seconds_range":[int(d.completion_sec.min()),int(d.completion_sec.max())]}
    log={"created_at_utc":datetime.now(timezone.utc).isoformat(),"file":str(BOOK),"sha256":sha(BOOK),"bytes":BOOK.stat().st_size,
         "workbook_sheets":["Overview","Study1_Synthetic","Study2_Synthetic","Codebook"],
         "self_description_evidence":["Overview title: Environmental Health Message Lab synthetic survey data",
             "Sheet names: Study1_Synthetic and Study2_Synthetic",
             "Codebook: Synthetic record ID; not a real person",
             "Codebook: seeded pseudo-random generation; effect sizes are assumptions, not observed estimates"],
         "archive_has_core_properties":"docProps/core.xml" in members,
         "platform_metadata_columns_present":False,"survey_start_or_end_timestamp_columns_present":False,
         "study1":frame(s1),"study2":frame(s2),
         "provenance_status":"UNVERIFIED_FOR_EMPIRICAL_REPORTING",
         "allowed_use":"pipeline testing, method demonstration, and consistency checking",
         "prohibited_claim":"Do not describe these rows as observed participants without a verified source export."}
    (OUT/"participant_data_provenance.json").write_text(json.dumps(log,indent=2,ensure_ascii=False),encoding="utf-8")
    return log

def mediation(s1,s2,boots=1000):
    # H4: parallel product-of-coefficients on the log-odds scale.
    spatial=(s1.S1K3.astype(str).str.upper()=="C").astype(float).to_numpy()
    base=np.column_stack([np.ones(len(s1)),s1.EXPLAIN,s1.MAP,s1.EXPLAIN*s1.MAP])
    meds=np.column_stack([s1.comprehension_mean,s1.trust_mean,spatial])
    outcome=np.column_stack([base,meds,s1.threat_mean,s1.efficacy_mean])
    y=s1.appropriate_action.to_numpy(int)
    def h4_once(ix):
        xb=base[ix]; mm=meds[ix]; bo=fit_logit(outcome[ix],y[ix])
        am=[np.linalg.lstsq(xb,mm[:,j],rcond=None)[0] for j in range(3)]
        return np.array([am[0][1]*bo[4],am[1][1]*bo[5],am[2][2]*bo[6]])
    point=h4_once(np.arange(len(s1))); draws=[]
    for _ in range(boots): draws.append(h4_once(RNG.integers(0,len(s1),len(s1))))
    draws=np.asarray(draws); names=["EXPLAIN_via_causal_comprehension","EXPLAIN_via_trust","MAP_via_spatial_correct"]
    h4=[{"path":n,"indirect_log_odds":float(v),"bootstrap_95_ci":ci(draws[:,j])} for j,(n,v) in enumerate(zip(names,point))]

    # H8: associative decomposition of GAP×REPAIR; not causal mediation.
    inter=s2.GAP*s2.REPAIR
    base2=np.column_stack([np.ones(len(s2)),s2.GAP,s2.REPAIR,inter])
    mednames=["uncertainty_comprehension","final_trust","threat_mean","efficacy_mean"]
    meds2=s2[mednames].to_numpy(float); out2=np.column_stack([base2,meds2]); y2=s2.appropriate_action.to_numpy(int)
    def h8_once(ix):
        xb=base2[ix]; mm=meds2[ix]; bo=fit_logit(out2[ix],y2[ix])
        return np.array([np.linalg.lstsq(xb,mm[:,j],rcond=None)[0][3]*bo[4+j] for j in range(4)])
    point2=h8_once(np.arange(len(s2))); draws2=[]
    for _ in range(boots): draws2.append(h8_once(RNG.integers(0,len(s2),len(s2))))
    draws2=np.asarray(draws2)
    h8=[{"path":"GAP_x_REPAIR_via_"+n,"associative_product_log_odds":float(v),"bootstrap_95_ci":ci(draws2[:,j])} for j,(n,v) in enumerate(zip(mednames,point2))]
    result={"status":"DEMONSTRATION_ON_SELF_IDENTIFIED_SYNTHETIC_WORKBOOK","bootstrap_resamples":boots,"H4":h4,"H8":h8,
            "interpretation":"Products are model-based associations on the log-odds scale. H8 is not explanation-specific causal mediation."}
    (OUT/"H4_H8_mediation_diagnostic.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    return result

def invariance_screen(s1,s2):
    constructs={"S1_comprehension":(s1,["S1C1","S1C2","S1C3","S1C4"]),"S1_trust":(s1,["S1T1","S1T2","S1T3"]),
        "S1_threat":(s1,["S1R1","S1R2"]),"S1_efficacy":(s1,["S1E1","S1E2"]),
        "S2_comprehension":(s2,["S2C1","S2C2"]),"S2_trust":(s2,["S2T3","S2T4","S2T5"]),
        "S2_threat":(s2,["S2R1","S2R2"]),"S2_efficacy":(s2,["S2E1","S2E2"])}
    rows=[]
    def loading(a):
        z=(a-a.mean(0))/a.std(0,ddof=0); vals,vecs=np.linalg.eigh(np.corrcoef(z,rowvar=False)); v=vecs[:,-1]
        if v.sum()<0:v=-v
        return v*np.sqrt(max(vals[-1],0))
    for name,(d,items) in constructs.items():
        pool=loading(d[items].to_numpy(float))
        for region,g in d.groupby("region"):
            l=loading(g[items].to_numpy(float)); cong=float(np.dot(l,pool)/(np.linalg.norm(l)*np.linalg.norm(pool)))
            rows.append({"construct":name,"region":region,"n":len(g),"tucker_congruence":cong,"max_abs_loading_difference":float(np.max(np.abs(l-pool)))})
    table=pd.DataFrame(rows); table.to_csv(OUT/"H9_loading_similarity_screen.csv",index=False)
    summary={"status":"SCREENING_ONLY_NOT_FORMAL_MEASUREMENT_INVARIANCE","minimum_tucker_congruence":float(table.tucker_congruence.min()),
             "maximum_loading_difference":float(table.max_abs_loading_difference.max()),
             "H9_decision":"Pending formal multigroup CFA; two-item factors require a jointly identified measurement model."}
    (OUT/"H9_invariance_status.json").write_text(json.dumps(summary,indent=2),encoding="utf-8"); return summary

def predictive(s1,s2):
    def z(v): v=pd.to_numeric(v,errors="coerce"); return (v-v.mean())/(v.std(ddof=0) or 1)
    frames=[]
    for study,d in [(1,s1.copy()),(2,s2.copy())]:
        q=pd.DataFrame({"participant_id":d.participant_id,"region":d.region,"target":d.appropriate_action,"study2":study-1,
            "factor1":d.EXPLAIN if study==1 else d.GAP,"factor2":d.MAP if study==1 else d.REPAIR,
            "age":d.age,"hazard_experience":d.hazard_experience,"map_use":d.map_use,"numeracy":d.numeracy_confidence,
            "prior_knowledge":d.prior_knowledge,"gov_trust":d.general_gov_trust,
            "comprehension":z(d.comprehension_mean if study==1 else d.uncertainty_comprehension),
            "trust":z(d.trust_mean if study==1 else d.final_trust),"threat":z(d.threat_mean),"efficacy":z(d.efficacy_mean),
            "fatigue":0 if study==1 else z(d.warning_fatigue),"fatigue_observed":study-1,
            "trust_update":0 if study==1 else z(d.final_trust-d.S2T0),"trust_update_observed":study-1})
        q["interaction"]=q.factor1*q.factor2; frames.append(q)
    d=pd.concat(frames,ignore_index=True)
    blocks={"M0_intercept":[],"M1_risk":["threat"],
        "M2_direct":["threat","study2","factor1","factor2","interaction","age","hazard_experience","map_use","numeracy","prior_knowledge","gov_trust"],
        "M3_process":["threat","study2","factor1","factor2","interaction","age","hazard_experience","map_use","numeracy","prior_knowledge","gov_trust","comprehension","trust","efficacy"],
        "M4_EHMRF":["threat","study2","factor1","factor2","interaction","age","hazard_experience","map_use","numeracy","prior_knowledge","gov_trust","comprehension","trust","efficacy","fatigue","fatigue_observed","trust_update","trust_update_observed"]}
    def prep(train,test,fs):
        if not fs:return np.ones((len(train),1)),np.ones((len(test),1))
        a=train[fs].apply(pd.to_numeric,errors="coerce"); b=test[fs].apply(pd.to_numeric,errors="coerce")
        med=a.median(); a=a.fillna(med); b=b.fillna(med); mean=a.mean(); sd=a.std(ddof=0).replace(0,1)
        return np.column_stack([np.ones(len(a)),((a-mean)/sd).to_numpy(float)]),np.column_stack([np.ones(len(b)),((b-mean)/sd).to_numpy(float)])
    preds={m:pd.Series(np.nan,index=d.index) for m in blocks}; foldrows=[]
    for region in sorted(d.region.unique()):
        te=d.region.eq(region); tr=~te
        for model,fs in blocks.items():
            xtr,xte=prep(d.loc[tr],d.loc[te],fs); b=fit_logit(xtr,d.loc[tr,"target"].to_numpy(int)); p=sigmoid(xte@b); preds[model].loc[te]=p
            foldrows.append({"region":region,"model":model,"n":int(te.sum()),**metrics(d.loc[te,"target"],p)})
    folds=pd.DataFrame(foldrows); folds.to_csv(OUT/"H10_region_fold_metrics.csv",index=False)
    overall=[]
    for model,p in preds.items(): overall.append({"model":model,"n":len(d),**metrics(d.target,p)})
    overall=pd.DataFrame(overall); overall.to_csv(OUT/"H10_model_ladder.csv",index=False)
    # Region-level bootstrap for M4-vs-M1 uncertainty.
    wide=folds.pivot(index="region",columns="model",values=["auc","brier","log_loss"]); boot={}
    regs=np.arange(len(wide))
    for metric in ["auc","brier","log_loss"]:
        delta=(wide[(metric,"M4_EHMRF")]-wide[(metric,"M1_risk")]).to_numpy(float)
        draws=[float(np.nanmean(delta[RNG.integers(0,len(regs),len(regs))])) for _ in range(10000)]
        boot[metric]={"mean_fold_delta_M4_minus_M1":float(np.nanmean(delta)),"region_bootstrap_95_ci":ci(draws)}
    # Prespecified process ablations, evaluated with the same outer folds.
    full=blocks["M4_EHMRF"]; groups={"no_comprehension":["comprehension"],"no_trust":["trust","trust_update","trust_update_observed"],
        "no_efficacy":["efficacy"],"no_fatigue":["fatigue","fatigue_observed"]}; ab=[]
    for label,drop in groups.items():
        fs=[f for f in full if f not in drop]; pred=pd.Series(np.nan,index=d.index)
        for region in sorted(d.region.unique()):
            te=d.region.eq(region); tr=~te; xtr,xte=prep(d.loc[tr],d.loc[te],fs); pred.loc[te]=sigmoid(xte@fit_logit(xtr,d.loc[tr,"target"].to_numpy(int)))
        ab.append({"model":label,**metrics(d.target,pred)})
    pd.DataFrame(ab).to_csv(OUT/"H10_ablation_metrics.csv",index=False)
    cal=pd.DataFrame({"observed":d.target,"predicted":preds["M4_EHMRF"]}); cal["bin"]=pd.qcut(cal.predicted,10,duplicates="drop")
    cal.groupby("bin",observed=True).agg(n=("observed","size"),predicted=("predicted","mean"),observed=("observed","mean")).reset_index(drop=True).to_csv(OUT/"H10_calibration.csv",index=False)
    result={"status":"DEMONSTRATION_ON_SELF_IDENTIFIED_SYNTHETIC_WORKBOOK","overall":overall.to_dict("records"),"fold_bootstrap":boot,
            "H10_decision":"Do not make an empirical H10 claim until rerun on a verified participant export."}
    (OUT/"H10_predictive_status.json").write_text(json.dumps(result,indent=2),encoding="utf-8"); return result

def study2_dynamic(s2):
    d=pd.DataFrame({"region":s2.region,"target":s2.appropriate_action,"GAP":s2.GAP,"REPAIR":s2.REPAIR,
        "interaction":s2.GAP*s2.REPAIR,"baseline_trust":s2.S2T0,"baseline_preparation":s2.S2A0,
        "uncertainty":s2.uncertainty_comprehension,"final_trust":s2.final_trust,"threat":s2.threat_mean,
        "efficacy":s2.efficacy_mean,"post_outcome_trust":s2.post_outcome_trust,"fatigue":s2.warning_fatigue,
        "trust_change":s2.final_trust-s2.S2T0})
    blocks={"D0_risk":["threat"],"D1_randomized":["threat","GAP","REPAIR","interaction","baseline_trust","baseline_preparation"],
        "D2_process":["threat","GAP","REPAIR","interaction","baseline_trust","baseline_preparation","uncertainty","final_trust","efficacy"],
        "D3_dynamic":["threat","GAP","REPAIR","interaction","baseline_trust","baseline_preparation","uncertainty","final_trust","efficacy","post_outcome_trust","fatigue","trust_change"]}
    def prep(a,b,fs):
        x=a[fs].astype(float); z=b[fs].astype(float); mean=x.mean(); sd=x.std(ddof=0).replace(0,1)
        return np.column_stack([np.ones(len(x)),((x-mean)/sd).to_numpy()]),np.column_stack([np.ones(len(z)),((z-mean)/sd).to_numpy()])
    rows=[]; pooled={m:pd.Series(np.nan,index=d.index) for m in blocks}
    for reg in sorted(d.region.unique()):
        te=d.region.eq(reg); tr=~te
        for name,fs in blocks.items():
            a,b=prep(d.loc[tr],d.loc[te],fs); p=sigmoid(b@fit_logit(a,d.loc[tr,"target"].to_numpy(int))); pooled[name].loc[te]=p
            rows.append({"region":reg,"model":name,"n":int(te.sum()),**metrics(d.loc[te,"target"],p)})
    pd.DataFrame(rows).to_csv(OUT/"Study2_dynamic_region_folds.csv",index=False)
    overall=pd.DataFrame([{"model":m,"n":len(d),**metrics(d.target,p)} for m,p in pooled.items()])
    overall.to_csv(OUT/"Study2_dynamic_model_ladder.csv",index=False)
    result={"status":"DEMONSTRATION_ON_SELF_IDENTIFIED_SYNTHETIC_WORKBOOK","overall":overall.to_dict("records"),
            "interpretation":"D3 tests whether sequential trust and fatigue improve held-region prediction beyond randomized and process blocks."}
    (OUT/"Study2_dynamic_status.json").write_text(json.dumps(result,indent=2),encoding="utf-8"); return result

def main():
    s1=pd.read_excel(BOOK,"Study1_Synthetic"); s2=pd.read_excel(BOOK,"Study2_Synthetic")
    result={"provenance":provenance(s1,s2),"mediation":mediation(s1,s2),"invariance":invariance_screen(s1,s2),"predictive":predictive(s1,s2),"study2_dynamic":study2_dynamic(s2)}
    print(json.dumps({"provenance_status":result["provenance"]["provenance_status"],"outputs":sorted(p.name for p in OUT.iterdir())},indent=2))
if __name__=="__main__": main()
