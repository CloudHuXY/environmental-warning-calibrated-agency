"""Covariate-adjusted, region-stratified bootstrap checks for H4 and H8.

H4 product paths use randomized Study 1 factors. H8 products remain an
associative decomposition of a randomized package interaction because the
follow-up package changes several components at once.
"""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd

from audit_and_complete_pending import fit_logit

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / "outputs" / "Environmental_Health_Message_Lab_模拟样本数据.xlsx"
OUT = ROOT / "analysis" / "mediation"
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(20260917)
BASELINE = ["age", "hazard_experience", "map_use", "numeracy_confidence", "prior_knowledge", "general_gov_trust"]


def design(df, f1, f2):
    cols = [np.ones(len(df)), df[f1].to_numpy(float), df[f2].to_numpy(float), (df[f1] * df[f2]).to_numpy(float)]
    for col in BASELINE:
        x = pd.to_numeric(df[col], errors="coerce").astype(float)
        x = x.fillna(x.median()); sd = x.std(ddof=0) or 1.0
        cols.append(((x - x.mean()) / sd).to_numpy())
    regions = sorted(df.region.astype(str).unique())
    for region in regions[1:]: cols.append(df.region.astype(str).eq(region).astype(float).to_numpy())
    return np.column_stack(cols)


def stratified_indices(df):
    pieces = []
    for _, idx in df.groupby("region", sort=True).groups.items():
        idx = np.asarray(list(idx), int)
        pieces.append(RNG.choice(idx, size=len(idx), replace=True))
    return np.concatenate(pieces)


def h4_once(df):
    x = design(df, "EXPLAIN", "MAP")
    spatial = df.S1K3.astype(str).eq("C").astype(float).to_numpy()
    meds = np.column_stack([df.comprehension_mean.to_numpy(float), df.trust_mean.to_numpy(float), spatial])
    a = np.linalg.lstsq(x, meds, rcond=None)[0]
    yx = np.column_stack([x, meds, df.threat_mean.to_numpy(float), df.efficacy_mean.to_numpy(float)])
    b = fit_logit(yx, df.appropriate_action.to_numpy(int))
    m0 = x.shape[1]
    return np.array([a[1, 0] * b[m0], a[1, 1] * b[m0 + 1], a[2, 2] * b[m0 + 2]])


def h8_once(df):
    x = design(df, "GAP", "REPAIR")
    meds = df[["uncertainty_comprehension", "final_trust", "threat_mean", "efficacy_mean"]].to_numpy(float)
    a = np.linalg.lstsq(x, meds, rcond=None)[0]
    yx = np.column_stack([x, meds])
    b = fit_logit(yx, df.appropriate_action.to_numpy(int))
    m0 = x.shape[1]
    return a[3, :] * b[m0:m0 + 4]


def run_one(study, label, df, func, names, boots=2000):
    df = df.reset_index(drop=True)
    point = func(df)
    draws = np.empty((boots, len(names)))
    for i in range(boots): draws[i] = func(df.iloc[stratified_indices(df)].reset_index(drop=True))
    return [{
        "study": study, "sample": label, "path": name, "estimate_log_odds": float(point[j]),
        "bootstrap_95_ci_low": float(np.quantile(draws[:, j], .025)),
        "bootstrap_95_ci_high": float(np.quantile(draws[:, j], .975)),
        "bootstrap_resamples": boots,
    } for j, name in enumerate(names)]


def main():
    s1 = pd.read_excel(BOOK, "Study1_Synthetic")
    s2 = pd.read_excel(BOOK, "Study2_Synthetic")
    rows = []
    h4_names = ["EXPLAIN_via_causal_comprehension", "EXPLAIN_via_trust", "MAP_via_spatial_correct"]
    h8_names = ["GAP_x_REPAIR_via_uncertainty_comprehension", "GAP_x_REPAIR_via_final_trust", "GAP_x_REPAIR_via_threat", "GAP_x_REPAIR_via_efficacy"]
    rows += run_one("Study 1", "all_records", s1, h4_once, h4_names)
    rows += run_one("Study 1", "attention_pass", s1[s1.attention_pass.eq(1)], h4_once, h4_names)
    rows += run_one("Study 2", "all_records", s2, h8_once, h8_names)
    rows += run_one("Study 2", "attention_pass", s2[s2.attention_pass.eq(1)], h8_once, h8_names)
    table = pd.DataFrame(rows)
    table["interval_excludes_zero"] = (table.bootstrap_95_ci_low > 0) | (table.bootstrap_95_ci_high < 0)
    table.to_csv(OUT / "mediation_robustness.csv", index=False)
    payload = {
        "status": "DIAGNOSTIC_UNTIL_SOURCE_EXPORT_RECONCILIATION",
        "method": "product-of-coefficients; baseline covariates and region fixed effects; region-stratified nonparametric bootstrap",
        "H8_scope": "associative package-level decomposition, not explanation-specific causal mediation",
        "results": table.to_dict("records"),
    }
    (OUT / "mediation_robustness.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(table.to_string(index=False))


if __name__ == "__main__": main()
