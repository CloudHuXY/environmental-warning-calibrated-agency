"""Prospective Study 2R validation and confirmatory analysis template.

This script never creates participant records. It accepts a Qualtrics CSV export,
checks the preregistered design, and writes machine-readable audit/results files.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED = {
    "response_id", "condition_code", "GAP", "EXPLAIN", "region_stratum",
    "language", "start_time", "end_time", "finished", "appropriate_action",
}
VALID_CONDITIONS = {
    "S2R-A": (0, 0), "S2R-B": (0, 1), "S2R-C": (1, 0), "S2R-D": (1, 1)
}


def validate(df: pd.DataFrame) -> dict:
    missing = sorted(REQUIRED - set(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    bad_codes = sorted(set(df["condition_code"].dropna()) - set(VALID_CONDITIONS))
    mismatched = 0
    for code, (gap, explain) in VALID_CONDITIONS.items():
        part = df[df["condition_code"] == code]
        mismatched += int(((part["GAP"] != gap) | (part["EXPLAIN"] != explain)).sum())
    return {
        "rows_received": int(len(df)),
        "unique_response_ids": int(df["response_id"].nunique(dropna=True)),
        "duplicate_response_ids": int(df["response_id"].duplicated(keep=False).sum()),
        "unknown_condition_codes": bad_codes,
        "condition_factor_mismatches": mismatched,
        "missing_primary_endpoint": int(df["appropriate_action"].isna().sum()),
        "cell_counts": df["condition_code"].value_counts(dropna=False).to_dict(),
        "region_counts": df["region_stratum"].value_counts(dropna=False).to_dict(),
        "language_counts": df["language"].value_counts(dropna=False).to_dict(),
    }


def fit_primary(df: pd.DataFrame, outcome: str = "appropriate_action") -> tuple[dict, pd.DataFrame]:
    expected_gap = df["condition_code"].map({k: v[0] for k, v in VALID_CONDITIONS.items()})
    expected_explain = df["condition_code"].map({k: v[1] for k, v in VALID_CONDITIONS.items()})
    analytic = df[
        (df["finished"] == 1)
        & df["response_id"].notna()
        & ~df["response_id"].duplicated(keep="first")
        & df[outcome].isin([0, 1])
        & df["condition_code"].isin(VALID_CONDITIONS)
        & df["GAP"].eq(expected_gap)
        & df["EXPLAIN"].eq(expected_explain)
    ].copy()
    region = pd.get_dummies(analytic["region_stratum"], prefix="region", drop_first=True, dtype=float)
    design = pd.DataFrame({
        "Intercept": 1.0,
        "GAP": analytic["GAP"].astype(float),
        "EXPLAIN": analytic["EXPLAIN"].astype(float),
        "GAP:EXPLAIN": analytic["GAP"].astype(float) * analytic["EXPLAIN"].astype(float),
    }, index=analytic.index)
    design = pd.concat([design, region.set_axis(analytic.index)], axis=1)
    names = list(design.columns)
    x = design.to_numpy(dtype=float)
    y = analytic[outcome].to_numpy(dtype=float)
    xtx_inv = np.linalg.pinv(x.T @ x)
    beta = xtx_inv @ x.T @ y
    residual = y - x @ beta
    leverage = np.einsum("ij,jk,ik->i", x, xtx_inv, x)
    scaled = residual / np.clip(1.0 - leverage, 1e-10, None)
    covariance = xtx_inv @ (x.T @ ((scaled ** 2)[:, None] * x)) @ xtx_inv
    b = pd.Series(beta, index=names)
    cov = pd.DataFrame(covariance, index=names, columns=names)
    simple = float(b["EXPLAIN"] + b["GAP:EXPLAIN"])
    var = (
        cov.loc["EXPLAIN", "EXPLAIN"]
        + cov.loc["GAP:EXPLAIN", "GAP:EXPLAIN"]
        + 2 * cov.loc["EXPLAIN", "GAP:EXPLAIN"]
    )
    se = float(np.sqrt(var))
    interaction_se = float(np.sqrt(cov.loc["GAP:EXPLAIN", "GAP:EXPLAIN"]))
    summary = {
        "analytic_n": int(len(analytic)),
        "outcome": outcome,
        "model": "HC3 linear probability model with region fixed effects",
        "primary_gap_explanation_risk_difference": simple,
        "primary_95_ci": [simple - 1.95996398454 * se, simple + 1.95996398454 * se],
        "interaction_estimate": float(b["GAP:EXPLAIN"]),
        "interaction_95_ci": [
            float(b["GAP:EXPLAIN"] - 1.95996398454 * interaction_se),
            float(b["GAP:EXPLAIN"] + 1.95996398454 * interaction_se),
        ],
        "coefficient_names": names,
    }
    cells = (
        analytic.groupby(["condition_code", "GAP", "EXPLAIN"], as_index=False)
        .agg(n=(outcome, "size"), outcome_rate=(outcome, "mean"))
    )
    return summary, cells


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("--outdir", type=Path, default=Path("analysis/study2r_results"))
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input_csv)
    for column in ["finished", "GAP", "EXPLAIN", "appropriate_action", "official_map_click", "route_download", "map_dwell_sec"]:
        if column in df:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    audit = validate(df)
    (args.outdir / "data_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )
    summary, cells = fit_primary(df)
    (args.outdir / "primary_results.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    cells.to_csv(args.outdir / "cell_rates.csv", index=False)
    behavioral = {}
    for outcome in ["official_map_click", "route_download"]:
        if outcome in df and df[outcome].isin([0, 1]).any():
            behavior_summary, behavior_cells = fit_primary(df, outcome)
            behavioral[outcome] = behavior_summary
            behavior_cells.to_csv(args.outdir / f"{outcome}_cell_rates.csv", index=False)
    if "map_dwell_sec" in df and df["map_dwell_sec"].notna().any():
        clicks = df["official_map_click"] if "official_map_click" in df else pd.Series(0, index=df.index)
        openers = df[clicks.eq(1) & df["map_dwell_sec"].ge(0)]
        behavioral["map_dwell_sec_among_openers"] = (
            openers.groupby(["condition_code", "GAP", "EXPLAIN"])["map_dwell_sec"]
            .agg(["count", "mean", "median"])
            .reset_index().to_dict(orient="records")
        )
    (args.outdir / "behavioral_results.json").write_text(
        json.dumps(behavioral, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"audit": audit, "primary": summary}, indent=2, default=str))


if __name__ == "__main__":
    main()
