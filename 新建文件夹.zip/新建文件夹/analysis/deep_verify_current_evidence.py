"""Independent, reproducible checks of the currently supplied research files.

This script validates structure, calculations, manuscript claims, and the metadata
overlay. It deliberately does not convert researcher-attested metadata into
source-system evidence.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT / "outputs" / "Environmental_Health_Message_Lab_模拟样本数据.xlsx"
METADATA = ROOT / "outputs" / "Environmental_Health_Message_Lab_研究者确认元数据版.xlsx"
OUT = ROOT / "analysis" / "deep_verification"
OUT.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def max_abs_error(a, b) -> float:
    return float(np.nanmax(np.abs(np.asarray(a, float) - np.asarray(b, float))))


def smd(x, treatment) -> float:
    x = pd.to_numeric(x, errors="coerce")
    t = pd.Series(treatment).astype(int)
    a, b = x[t.eq(1)], x[t.eq(0)]
    pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2)
    return float((a.mean() - b.mean()) / pooled) if pooled else 0.0


def check_study(df: pd.DataFrame, study: int) -> tuple[dict, list[dict]]:
    factor1, factor2 = ("EXPLAIN", "MAP") if study == 1 else ("GAP", "REPAIR")
    expected_codes = (
        {(0, 0): "S1A", (0, 1): "S1B", (1, 0): "S1C", (1, 1): "S1D"}
        if study == 1
        else {(0, 0): "S2A", (0, 1): "S2B", (1, 0): "S2C", (1, 1): "S2D"}
    )
    expected = [expected_codes[(int(a), int(b))] for a, b in zip(df[factor1], df[factor2])]
    mapping_errors = int((df["condition_code"].astype(str).to_numpy() != np.asarray(expected)).sum())

    likert = [c for c in df.columns if c.startswith(f"S{study}") and pd.api.types.is_numeric_dtype(df[c])]
    likert = [c for c in likert if c not in {"S1A4", "S2B3"}]
    out_of_range = {}
    for c in likert:
        bad = int((~pd.to_numeric(df[c], errors="coerce").between(1, 7)).sum())
        if bad:
            out_of_range[c] = bad

    derived = {}
    if study == 1:
        derived = {
            "comprehension_mean": max_abs_error(df.comprehension_mean, df[["S1C1", "S1C2", "S1C3", "S1C4"]].mean(axis=1)),
            "trust_mean": max_abs_error(df.trust_mean, df[["S1T1", "S1T2", "S1T3"]].mean(axis=1)),
            "threat_mean": max_abs_error(df.threat_mean, df[["S1R1", "S1R2"]].mean(axis=1)),
            "efficacy_mean": max_abs_error(df.efficacy_mean, df[["S1E1", "S1E2"]].mean(axis=1)),
        }
    else:
        derived = {
            "post_outcome_trust": max_abs_error(df.post_outcome_trust, pd.concat([df.S2T1, 8 - df.S2T2], axis=1).mean(axis=1)),
            "warning_fatigue": max_abs_error(df.warning_fatigue, df[["S2W1", "S2W2"]].mean(axis=1)),
            "uncertainty_comprehension": max_abs_error(df.uncertainty_comprehension, df[["S2C1", "S2C2"]].mean(axis=1)),
            "final_trust": max_abs_error(df.final_trust, df[["S2T3", "S2T4", "S2T5"]].mean(axis=1)),
            "threat_mean": max_abs_error(df.threat_mean, df[["S2R1", "S2R2"]].mean(axis=1)),
            "efficacy_mean": max_abs_error(df.efficacy_mean, df[["S2E1", "S2E2"]].mean(axis=1)),
            "action_intention": max_abs_error(df.action_intention, pd.concat([df.S2A1, 8 - df.S2A2, df.S2A3], axis=1).mean(axis=1)),
        }

    balance_rows = []
    baseline = ["age", "hazard_experience", "map_use", "numeracy_confidence", "prior_knowledge", "general_gov_trust"]
    for factor in [factor1, factor2]:
        for variable in baseline:
            balance_rows.append({"study": study, "factor": factor, "variable": variable, "smd": smd(df[variable], df[factor])})

    by_region_condition = df.groupby(["region", "condition_code"]).size()
    report = {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "participant_id_duplicates": int(df.participant_id.duplicated().sum()),
        "exact_row_duplicates": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "missing_by_column": {str(k): int(v) for k, v in df.isna().sum()[df.isna().sum().gt(0)].items()},
        "condition_mapping_errors": mapping_errors,
        "condition_counts": {str(k): int(v) for k, v in df.condition_code.value_counts().sort_index().items()},
        "region_counts": {str(k): int(v) for k, v in df.region.value_counts().sort_index().items()},
        "region_condition_min_n": int(by_region_condition.min()),
        "region_condition_max_n": int(by_region_condition.max()),
        "likert_out_of_range": out_of_range,
        "binary_outcome_values": sorted(pd.to_numeric(df.appropriate_action).dropna().unique().astype(int).tolist()),
        "attention_failures_retained": int(df.attention_pass.eq(0).sum()),
        "completion_seconds_min": int(df.completion_sec.min()),
        "completion_seconds_max": int(df.completion_sec.max()),
        "derived_score_max_abs_error": derived,
        "max_abs_baseline_smd": float(max(abs(r["smd"]) for r in balance_rows)),
    }
    return report, balance_rows


def main() -> None:
    s1 = pd.read_excel(ORIGINAL, "Study1_Synthetic")
    s2 = pd.read_excel(ORIGINAL, "Study2_Synthetic")
    m1 = pd.read_excel(METADATA, "Study1_Synthetic")
    m2 = pd.read_excel(METADATA, "Study2_Synthetic")

    r1, b1 = check_study(s1, 1)
    r2, b2 = check_study(s2, 2)
    balance = pd.DataFrame(b1 + b2)
    balance.to_csv(OUT / "randomization_balance_smd.csv", index=False)

    common1 = list(s1.columns)
    common2 = list(s2.columns)
    metadata_fields = [
        "data_source_record", "recruitment_platform", "survey_platform",
        "recruitment_start_date", "recruitment_end_date", "response_ip_address",
        "response_ip_sha256", "response_start_timestamp", "response_end_timestamp", "metadata_status",
    ]
    overlay = {
        "study1_original_columns_unchanged": bool(s1.equals(m1[common1])),
        "study2_original_columns_unchanged": bool(s2.equals(m2[common2])),
        "metadata_fields_present": {c: bool(c in m1.columns and c in m2.columns) for c in metadata_fields},
        "recruitment_platform_values": sorted(set(m1.recruitment_platform.dropna().astype(str)) | set(m2.recruitment_platform.dropna().astype(str))),
        "survey_platform_values": sorted(set(m1.survey_platform.dropna().astype(str)) | set(m2.survey_platform.dropna().astype(str))),
        "recruitment_start_values": sorted(set(m1.recruitment_start_date.dropna().astype(str)) | set(m2.recruitment_start_date.dropna().astype(str))),
        "ip_nonmissing": int(m1.response_ip_address.notna().sum() + m2.response_ip_address.notna().sum()),
        "start_timestamp_nonmissing": int(m1.response_start_timestamp.notna().sum() + m2.response_start_timestamp.notna().sum()),
        "end_timestamp_nonmissing": int(m1.response_end_timestamp.notna().sum() + m2.response_end_timestamp.notna().sum()),
    }

    cross_study_duplicate_ids = int(len(set(s1.participant_id) & set(s2.participant_id)))
    result = {
        "files": {
            "original": {"path": str(ORIGINAL), "sha256": sha256(ORIGINAL), "bytes": ORIGINAL.stat().st_size},
            "metadata_copy": {"path": str(METADATA), "sha256": sha256(METADATA), "bytes": METADATA.stat().st_size},
        },
        "grain": "one analytic record per participant per study",
        "study1": r1,
        "study2": r2,
        "cross_study_duplicate_participant_ids": cross_study_duplicate_ids,
        "metadata_overlay": overlay,
        "source_evidence_status": "RESEARCHER_ATTESTED_PLATFORM_AND_START_DATE; SOURCE-SYSTEM EXPORT NOT PRESENT",
        "empirical_claim_gate": "BLOCKED UNTIL ORIGINAL QUALTRICS EXPORT OR EQUIVALENT IMMUTABLE COLLECTION RECORD IS RECONCILED",
    }
    (OUT / "deep_verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# Deep verification of current evidence",
        "",
        f"Original workbook SHA-256: `{result['files']['original']['sha256']}`",
        f"Metadata-copy SHA-256: `{result['files']['metadata_copy']['sha256']}`",
        "",
        "## Verified",
        "",
        f"- Participant grain: one row per participant; duplicate IDs are {r1['participant_id_duplicates']} in Study 1 and {r2['participant_id_duplicates']} in Study 2.",
        f"- Condition coding errors: {r1['condition_mapping_errors']} in Study 1 and {r2['condition_mapping_errors']} in Study 2.",
        f"- Derived-score maximum absolute error: {max(max(r1['derived_score_max_abs_error'].values()), max(r2['derived_score_max_abs_error'].values())):.3g}.",
        f"- Metadata overlay preserved every original participant-data column: {overlay['study1_original_columns_unchanged'] and overlay['study2_original_columns_unchanged']}.",
        f"- Maximum absolute baseline standardized mean difference across randomized factors: {max(r1['max_abs_baseline_smd'], r2['max_abs_baseline_smd']):.3f}.",
        "",
        "## Material limits",
        "",
        f"- Retained attention-check failures: {r1['attention_failures_retained']} in Study 1 and {r2['attention_failures_retained']} in Study 2; the analysis is therefore an all-record/ITT-style analysis unless exclusions are redefined prospectively.",
        "- No participant IP address, response start timestamp, or response end timestamp is present in the supplied files.",
        "- Prolific, Qualtrics, and the 2026-09-15 start date are researcher-attested metadata added after the participant table was created.",
        "- The original workbook self-identifies as synthetic; the source-system export is absent. This blocks empirical provenance verification.",
        "",
        "## Status",
        "",
        "The calculations and internal table structure are reproducible. Empirical-source verification is not complete.",
    ]
    (OUT / "DEEP_VERIFICATION_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
