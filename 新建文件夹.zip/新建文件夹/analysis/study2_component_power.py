"""Conservative normal-approximation power for the component-controlled Study 2."""
from pathlib import Path
from math import erf, sqrt
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "study2_design"
OUT.mkdir(parents=True, exist_ok=True)


def cdf(x):
    return 0.5 * (1 + erf(x / sqrt(2)))


def two_sided_power(ncp, critical=1.959963984540054):
    return 1 - cdf(critical - ncp) + cdf(-critical - ncp)


rows = []
for total_n in range(1600, 5601, 400):
    n_cell = total_n / 4
    for effect in (0.08, 0.10, 0.12):
        # Worst-case Bernoulli variance p(1-p)=.25.
        se_simple = sqrt(0.5 / n_cell)
        se_interaction = sqrt(1.0 / n_cell)
        rows.append({
            "analytic_total_n": total_n,
            "n_per_cell": int(n_cell),
            "risk_difference": effect,
            "power_gap_simple_effect": two_sided_power(effect / se_simple),
            "power_gap_by_explanation_interaction": two_sided_power(effect / se_interaction),
        })

df = pd.DataFrame(rows)
df.to_csv(OUT / "power_grid.csv", index=False)
selected = df[(df.analytic_total_n == 4800) & (df.risk_difference == 0.10)].iloc[0].to_dict()
payload = {
    "primary_design": "2 (forecast-outcome gap) x 2 (causal explanation) between participants",
    "primary_binary_endpoint": "appropriate protective action",
    "assumption": "worst-case Bernoulli variance of 0.25 in every cell; two-sided alpha .05",
    "target_analytic_n": 4800,
    "target_per_cell": 1200,
    "recruitment_target_allowing_11_percent_attrition": 5400,
    "selected_power": selected,
    "interpretation": "N=4,800 gives approximately 99.8% power for a 10-point explanation effect within the gap condition and 93% power for a 10-point difference-in-differences interaction.",
}
(OUT / "power_decision.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(json.dumps(payload, indent=2))
