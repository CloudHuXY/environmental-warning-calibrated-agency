# Ordinal multigroup CFA sensitivity analysis for EWUCM.
# Requires: R >= 4.3, lavaan, readxl, dplyr, readr.
# Run only after reconciling the participant workbook with the immutable source export.

suppressPackageStartupMessages({
  library(lavaan)
  library(readxl)
  library(dplyr)
  library(readr)
})

book <- file.path("outputs", "Environmental_Health_Message_Lab_模拟样本数据.xlsx")
out_dir <- file.path("analysis", "ordinal_cfa")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

specs <- list(
  Study1 = list(
    sheet = "Study1_Synthetic",
    model = paste(
      "causal_understanding =~ S1C1 + S1C2 + S1C3 + S1C4",
      "calibrated_trust =~ S1T1 + S1T2 + S1T3",
      "threat_appraisal =~ S1R1 + S1R2",
      "response_efficacy =~ S1E1 + S1E2",
      sep = "\n"
    ),
    items = c("S1C1","S1C2","S1C3","S1C4","S1T1","S1T2","S1T3","S1R1","S1R2","S1E1","S1E2")
  ),
  Study2 = list(
    sheet = "Study2_Synthetic",
    model = paste(
      "uncertainty_understanding =~ S2C1 + S2C2",
      "calibrated_trust =~ S2T3 + S2T4 + S2T5",
      "threat_appraisal =~ S2R1 + S2R2",
      "response_efficacy =~ S2E1 + S2E2",
      "action_intention =~ S2A1 + S2A2 + S2A3",
      sep = "\n"
    ),
    items = c("S2C1","S2C2","S2T3","S2T4","S2T5","S2R1","S2R2","S2E1","S2E2","S2A1","S2A2","S2A3")
  )
)

rows <- list()
for (study in names(specs)) {
  sp <- specs[[study]]
  dat <- read_excel(book, sheet = sp$sheet)
  if (study == "Study2") dat$S2A2 <- 8 - as.numeric(dat$S2A2)
  dat <- dat %>% mutate(region = factor(region))
  dat[sp$items] <- lapply(dat[sp$items], function(x) ordered(as.integer(x), levels = 1:7))

  fits <- list(
    configural = cfa(sp$model, data = dat, group = "region", estimator = "WLSMV",
                     ordered = sp$items, parameterization = "theta", std.lv = TRUE),
    metric = cfa(sp$model, data = dat, group = "region", estimator = "WLSMV",
                 ordered = sp$items, parameterization = "theta", std.lv = TRUE,
                 group.equal = "loadings"),
    scalar_threshold = cfa(sp$model, data = dat, group = "region", estimator = "WLSMV",
                           ordered = sp$items, parameterization = "theta", std.lv = TRUE,
                           group.equal = c("loadings", "thresholds"))
  )

  previous <- NULL
  for (level in names(fits)) {
    fm <- fitMeasures(fits[[level]], c("cfi.scaled", "tli.scaled", "rmsea.scaled", "srmr"))
    current <- tibble(
      study = study,
      level = level,
      cfi = unname(fm[["cfi.scaled"]]),
      tli = unname(fm[["tli.scaled"]]),
      rmsea = unname(fm[["rmsea.scaled"]]),
      srmr = unname(fm[["srmr"]]),
      delta_cfi = if (is.null(previous)) NA_real_ else unname(fm[["cfi.scaled"]]) - previous$cfi,
      delta_rmsea = if (is.null(previous)) NA_real_ else unname(fm[["rmsea.scaled"]]) - previous$rmsea
    )
    rows[[length(rows) + 1]] <- current
    previous <- current
  }
  saveRDS(fits, file.path(out_dir, paste0(study, "_ordinal_fits.rds")))
}

result <- bind_rows(rows) %>%
  mutate(decision = case_when(
    level == "configural" ~ if_else(cfi >= .90 & rmsea <= .08 & srmr <= .08, "adequate configural fit", "inadequate configural fit"),
    delta_cfi >= -.010 & delta_rmsea <= .015 ~ "invariance supported",
    TRUE ~ "invariance not supported"
  ))

write_csv(result, file.path(out_dir, "ordinal_invariance_fit.csv"))
print(result)
