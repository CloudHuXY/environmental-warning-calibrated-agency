# Study 2R component-controlled preregistration

**Status:** Prospective design. Register before inspecting outcome data.  
**Design:** 2 (forecast–outcome gap) × 2 (causal explanation), between participants.  
**Target:** 4,800 analyzable participants; recruit up to 5,400; 1,200 analyzable participants per cell.  

## Primary estimand

Explanation risk difference on appropriate protective action within `GAP = 1`. The secondary factorial estimand is the `GAP × EXPLAIN` difference in differences.

## Identification

The two follow-up messages hold probability, model agreement, action instructions, timing, layout, and visual prominence constant. The randomized paragraphs contain exactly 48 words each.

## Confirmatory model

`Y = β0 + β1 GAP + β2 EXPLAIN + β3 GAP×EXPLAIN + region fixed effects + ε`

Primary contrast: `β2 + β3`. Report HC3 risk differences and 95% confidence intervals, with logistic regression as sensitivity analysis.

## Files

- `condition_matrix.csv`: immutable four-cell mapping.
- `power_grid.csv` and `power_decision.json`: conservative binary-outcome power calculation.
- `Figure_Study2R_Design.png`: design diagram.
- Full stimuli, measures, hypotheses, exclusions, and decision rules are in `outputs/EWUCM_Study2_Component_Controlled_Protocol.docx`.
